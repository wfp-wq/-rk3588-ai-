#ifndef _RKNN_YOLOV8_DEMO_POSTPROCESS_H_
#define _RKNN_YOLOV8_DEMO_POSTPROCESS_H_

#include <stdint.h>
#include <vector>
#include "rknn_api.h"
#include "common.h"
#include "image_utils.h"
#include "yolov8.h"

#define OBJ_NAME_MAX_SIZE 64
#define OBJ_NUMB_MAX_SIZE 128
#define OBJ_CLASS_NUM 2
#define NMS_THRESH 0.1 // NMS阀值，消除重复框
#define BOX_THRESH 0.25 // 置信度阀值

 //class rknn_app_context_t;

typedef struct {
    image_rect_t box;// 边界框（位置信息）
    float prop;// 置信度（概率）
    int cls_id;// 类别ID
} object_detect_result;// 这个结构体是目标检测结果的数据结构，用于存储单个检测到的物体的完整信息

typedef struct {
    int id; // 结果ID（通常未使用或保留）
    int count; // 实际检测到的目标数量
    object_detect_result results[OBJ_NUMB_MAX_SIZE]; // 最多存储128个检测结果
} object_detect_result_list; //目标检测结果列表结构体

int init_post_process();
void deinit_post_process();
char *coco_cls_to_name(int cls_id);
int post_process(rknn_app_context_t *app_ctx, void *outputs, letterbox_t *letter_box, float conf_threshold, float nms_threshold, object_detect_result_list *od_results);

void deinitPostProcess();
#endif //_RKNN_YOLOV8_DEMO_POSTPROCESS_H_
