#ifndef _RKNN_DEMO_YOLOV8_H_
#define _RKNN_DEMO_YOLOV8_H_

#include "rknn_api.h"
#include "common.h"
#include<QStringList>
#include<QRect>
#include <QImage>
#include<QByteArray>

extern const char *image_path; //这里声明const char *image_path常量
struct DetectionResults {
    QStringList items; // 检测到的物体类别名称列表
    QStringList BOX; // 检测框坐标的字符串列表（如 "x,y,w,h"）
    QList<QRect>detectionBoxes; //检测框的矩形列表（Qt格式）
    int targetsCount; // 检测到的物体总数
    QImage img; // 处理后的图像（画了框的图片）
};

DetectionResults img_main();
DetectionResults img_main(QString imagepath);

typedef struct {
    rknn_context rknn_ctx;
    rknn_input_output_num io_num; // 输入输出数量信息，存储模型的输入和输出节点个数。
    rknn_tensor_attr* input_attrs; // 输入张量属性数组，存储每个输入张量的详细信息
    rknn_tensor_attr* output_attrs; // rknn_tensor_attr* output_attrs
#if defined(RV1106_1103)
    typedef struct {
        char *dma_buf_virt_addr;
        int dma_buf_fd;
        int size;
    }rknn_dma_buf;
#endif
#if defined(RV1106_1103) 
    rknn_tensor_mem* input_mems[1];
    rknn_tensor_mem* output_mems[9];
    rknn_dma_buf img_dma_buf;
#endif
#if defined(ZERO_COPY)  
    rknn_tensor_mem* input_mems[1];
    rknn_tensor_mem* output_mems[9];
    rknn_tensor_attr* input_native_attrs;
    rknn_tensor_attr* output_native_attrs;
#endif
    int model_channel;
    int model_width;
    int model_height;
    bool is_quant;
} rknn_app_context_t;

#include "postprocess.h"

int init_yolov8_model(const char* model_path, rknn_app_context_t* app_ctx);

int release_yolov8_model(rknn_app_context_t* app_ctx);

int inference_yolov8_model(rknn_app_context_t* app_ctx, image_buffer_t* img, object_detect_result_list* od_results);

#endif //_RKNN_DEMO_YOLOV8_H_
