#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "yolov8.h"
#include "Mcommon.h"
#include "file_utils.h"
#include "image_utils.h"
#include "RgaUtils.h"   //添加内容

static void dump_tensor_attr(rknn_tensor_attr *attr)
{
    printf("  index=%d, name=%s, n_dims=%d, dims=[%d, %d, %d, %d], n_elems=%d, size=%d, fmt=%s, type=%s, qnt_type=%s, "
           "zp=%d, scale=%f\n",
           attr->index, attr->name, attr->n_dims, attr->dims[0], attr->dims[1], attr->dims[2], attr->dims[3],
           attr->n_elems, attr->size, get_format_string(attr->fmt), get_type_string(attr->type),
           get_qnt_type_string(attr->qnt_type), attr->zp, attr->scale);
}

// 函数作用是，将结构体初始化，即将rknn的模型都输入进定义好的结构体rknn_app_context_t中
int init_yolov8_model(const char *model_path, rknn_app_context_t *app_ctx)
{
    int ret;
    int model_len = 0;
    char *model;
    rknn_context ctx = 0;

    // Load RKNN Model
    model_len = read_data_from_file(model_path, &model);//返回值是读取到的长度
    if (model == NULL)
    {
        printf("load_model fail!\n");
        return -1;
    }

    ret = rknn_init(&ctx, model, model_len, 0, NULL);//把rknn模型加载到ctx中
    free(model);
    if (ret < 0)
    {
        printf("rknn_init fail! ret=%d\n", ret);
        return -1;
    }

    // Get Model Input Output Number，用io_num接收
    rknn_input_output_num io_num;//定义一个结构体对象
    ret = rknn_query(ctx, RKNN_QUERY_IN_OUT_NUM, &io_num, sizeof(io_num));//RKNN_QUERY_IN_OUT_NUM是枚举对象，代表这里函数用到查询输入或输出的个数
    if (ret != RKNN_SUCC)//RKNN_SUCC也是枚举量，这里代表运行正常
    {
        printf("rknn_query fail! ret=%d\n", ret);
        return -1;
    }

    // Get Model Input Info(瑞芯微训练出来的模型有1个输入9个输出)
    printf("input tensors:\n");
    rknn_tensor_attr input_attrs[io_num.n_input];
    memset(input_attrs, 0, sizeof(input_attrs));
    // 遍历并打印模型所有输入张量的详细信息，用于调试和确认模型输入配置是否正确。
    for (int i = 0; i < io_num.n_input; i++)
    {
        input_attrs[i].index = i;
        ret = rknn_query(ctx, RKNN_QUERY_INPUT_ATTR, &(input_attrs[i]), sizeof(rknn_tensor_attr));//这里RKNN_QUERY_INPUT_ATTR，作用是查询输入张量的属性
        if (ret != RKNN_SUCC)
        {
            printf("rknn_query fail! ret=%d\n", ret);
            return -1;
        }
        dump_tensor_attr(&(input_attrs[i]));//输出“输入”张量的所有属性
    }

    // Get Model Output Info
    printf("output tensors:\n");
    rknn_tensor_attr output_attrs[io_num.n_output];
    memset(output_attrs, 0, sizeof(output_attrs));
    // 查询并打印模型所有输出张量的详细信息，与之前输入张量的查询是对称的操作。
    for (int i = 0; i < io_num.n_output; i++)
    {
        output_attrs[i].index = i;
        ret = rknn_query(ctx, RKNN_QUERY_OUTPUT_ATTR, &(output_attrs[i]), sizeof(rknn_tensor_attr));//作用是查询输出张量的属性
        if (ret != RKNN_SUCC)
        {
            printf("rknn_query fail! ret=%d\n", ret);
            return -1;
        }
        dump_tensor_attr(&(output_attrs[i]));//输出“输出”张量的所有属性
    }

    // Set to context
    app_ctx->rknn_ctx = ctx; //通过传入指针对结构体里的变量赋值

    // TODO
    //判断模型输出是否为INT8量化类型，并据此设置一个标志位。量化:将浮点数（如FP32）转换为整数（如INT8）的过程
    if (output_attrs[0].qnt_type == RKNN_TENSOR_QNT_AFFINE_ASYMMETRIC && output_attrs[0].type == RKNN_TENSOR_INT8)
    {
        app_ctx->is_quant = true;
    }
    else
    {
        app_ctx->is_quant = false;
    }

    app_ctx->io_num = io_num;
    //先开辟对映的内存空间，再将输入张量属性从局部变量复制到应用上下文中，以便长期保存和使用。
    app_ctx->input_attrs = (rknn_tensor_attr *)malloc(io_num.n_input * sizeof(rknn_tensor_attr));
    memcpy(app_ctx->input_attrs, input_attrs, io_num.n_input * sizeof(rknn_tensor_attr));
    app_ctx->output_attrs = (rknn_tensor_attr *)malloc(io_num.n_output * sizeof(rknn_tensor_attr));
    memcpy(app_ctx->output_attrs, output_attrs, io_num.n_output * sizeof(rknn_tensor_attr));

    //PyTorch用的是NCHW模式,格式为:dims = [batch, channel, height, width]
    if (input_attrs[0].fmt == RKNN_TENSOR_NCHW)
    {
        printf("model is NCHW input fmt\n");
        app_ctx->model_channel = input_attrs[0].dims[1];
        app_ctx->model_height = input_attrs[0].dims[2];
        app_ctx->model_width = input_attrs[0].dims[3];
    }

    //tensowflow用的是NHWC模式,格式为:dims = [batch, height, width, channel]
    else
    {
        printf("model is NHWC input fmt\n");
        app_ctx->model_height = input_attrs[0].dims[1];
        app_ctx->model_width = input_attrs[0].dims[2];
        app_ctx->model_channel = input_attrs[0].dims[3];
    }
    return 0;
}

int release_yolov8_model(rknn_app_context_t *app_ctx)
{
    if (app_ctx->input_attrs != NULL)
    {
        free(app_ctx->input_attrs);
        app_ctx->input_attrs = NULL;
    }
    if (app_ctx->output_attrs != NULL)
    {
        free(app_ctx->output_attrs);
        app_ctx->output_attrs = NULL;
    }
    if (app_ctx->rknn_ctx != 0)
    {
        rknn_destroy(app_ctx->rknn_ctx);
        app_ctx->rknn_ctx = 0;
    }
    return 0;
}

int inference_yolov8_model(rknn_app_context_t *app_ctx, image_buffer_t *img, object_detect_result_list *od_results)
{
    int ret;
    image_buffer_t dst_img;
    letterbox_t letter_box; //记录图像预处理时"Letterbox"操作的相关参数，以便后续能够将检测框坐标反向映射回原始图像。
    rknn_input inputs[app_ctx->io_num.n_input]; // 由app_ctx得到模型有几个输入，创造输入数组保存输入数据
    rknn_output outputs[app_ctx->io_num.n_output];// 由app_ctx得到模型有几个输出，创造输出数组保存输出数据，瑞芯微训练的模型有九个输出
    const float nms_threshold = NMS_THRESH;      // 默认的NMS阈值,去除重复框
    const float box_conf_threshold = BOX_THRESH; // 默认的置信度阈值
    int bg_color = 114;

    if ((!app_ctx) || !(img) || (!od_results))
    {
        printf("参数错误: app_ctx=%p, img=%p, od_results=%p\n", app_ctx, img, od_results);
        return -1;
    }

    memset(od_results, 0x00, sizeof(*od_results));
    memset(&letter_box, 0, sizeof(letterbox_t));
    memset(&dst_img, 0, sizeof(image_buffer_t));
    memset(inputs, 0, sizeof(inputs));
    memset(outputs, 0, sizeof(outputs));

    // Pre Process
    dst_img.width = app_ctx->model_width;
    dst_img.height = app_ctx->model_height;
    dst_img.format = IMAGE_FORMAT_RGB888;
    dst_img.size = get_image_size(&dst_img);
    dst_img.virt_addr = (unsigned char *)malloc(dst_img.size);
    if (dst_img.virt_addr == NULL)
    {
        printf("malloc buffer size:%d fail!\n", dst_img.size);
        return -1;
    }

    // letterbox
    //将原始图像img转换为模型所需要的dst_img图像，将转换的记录给letter_box保留，到时侯可以将转换后的图像恢复原图形的大小，bg_color代表填充颜色（灰色值，如 114）
    ret = convert_image_with_letterbox(img, &dst_img, &letter_box, bg_color);
    if (ret < 0)
    {
        printf("convert_image_with_letterbox fail! ret=%d\n", ret);
        free(dst_img.virt_addr);
        return -1;
    }

    // Set Input Data
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].size = app_ctx->model_width * app_ctx->model_height * app_ctx->model_channel;
    inputs[0].buf = dst_img.virt_addr;
    // 把输入的个数'io_num.n_input'=1，和输入的数据inputs传给ctx，为rknn模型识别作准备
    ret = rknn_inputs_set(app_ctx->rknn_ctx, app_ctx->io_num.n_input, inputs);//这三个参数都是输入，并且不会被改变，用于配置内置NPU的寄存器
    if (ret < 0)
    {
        printf("rknn_input_set fail! ret=%d\n", ret);
        free(dst_img.virt_addr);
        return -1;
    }

    // Run
    printf("rknn_run\n");
    ret = rknn_run(app_ctx->rknn_ctx, nullptr);//nullptr虽然没用但是一定得传入参数
    if (ret < 0)
    {
        printf("rknn_run fail! ret=%d\n", ret);
        free(dst_img.virt_addr);
        return -1;
    }
    printf("rknn_run 完成\n");

    // Get Output
    memset(outputs, 0, sizeof(outputs));
    for (int i = 0; i < app_ctx->io_num.n_output; i++) //因为rknn模型的输出有9个，所以这里需要用到循环
    {
        outputs[i].index = i;
        // 这里的is_quant在初始化里判断过是否为量化模型，在这里，若果是量化模型，则输出保持uint8_t类型，否则转为float
        outputs[i].want_float = (!app_ctx->is_quant);
        printf("输出[%d]: want_float=%d\n", i, outputs[i].want_float);
    }
    // 从 RKNN 模型的ctx中获取推理结果（输出数据），根据数量io_num.n_output=9放到outputs中
    ret = rknn_outputs_get(app_ctx->rknn_ctx, app_ctx->io_num.n_output, outputs, NULL);
    if (ret < 0)
    {
        printf("rknn_outputs_get fail! ret=%d\n", ret);
        goto out;
    }
    printf("输出获取成功，共 %d 个输出\n", app_ctx->io_num.n_output);


    // Post Process
    // 将 RKNN 模型输出的原始数据（检测框、置信度、类别），解析、过滤、去重，最终转换为程序可用的目标检测结果列表。

    post_process(app_ctx, outputs, &letter_box, box_conf_threshold, nms_threshold, od_results);

    // 打印检测结果详情
    if (od_results->count > 0) {
        for (int i = 0; i < od_results->count; i++) {
            printf("检测结果[%d]: class=%d, prob=%.3f, box=[%d,%d,%d,%d]\n",
                   i,
                   od_results->results[i].cls_id,
                   od_results->results[i].prop,
                   od_results->results[i].box.left,
                   od_results->results[i].box.top,
                   od_results->results[i].box.right,
                   od_results->results[i].box.bottom);
        }
    } else {
        printf("警告: 没有检测到任何目标！\n");
    }

    // Remeber to release rknn output
    rknn_outputs_release(app_ctx->rknn_ctx, app_ctx->io_num.n_output, outputs);

out:
    if (dst_img.virt_addr != NULL)
    {
        free(dst_img.virt_addr);
    }

    return ret;
}
