#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "image_utils.h"
#include "file_utils.h"
#include "image_drawing.h"
#include "yolov8.h"
#include "img_thread.h"
#include <QString>
#include<QComboBox>
//这里绘制用的不是opencv


#if defined(RV1106_1103) 
    #include "dma_alloc.hpp"
#endif

/*-------------------------------------------
                  Main Function
-------------------------------------------*/
//int main(int argc, char **argv)
const char *image_path=""; //这里定义一下，否则mainwindow.cpp里面用会显示未定义。不用担心重定义，只用void img_main()里面的代码，涉及不到上面

//单图片检测+文件夹检测共用，按照单图片检测的逻辑写的，文件夹检测就是反复用单图片检测
DetectionResults img_main(QString imagepath)
{
    //QString转换为char*，后面处理图像的read_image的关于图像路径的参数类型是char*.即便存储统一种类的文件，类型也会不同。例如：char和String
    QByteArray ba = imagepath.toLocal8Bit(); //QByteArray是一个类，他里面开辟了一块存放char* 的内存，并且可以自动释放
    image_path = ba.constData();//用constData()将QByteArray类里面存放的char* 内容引出来
    const char *model_path = "./model/yolov8.rknn";             //写的是buildroot上的路径，不是Ubuntu上的
    DetectionResults results;
    int cropCount = 0; // 用于记录 crop 的计数
    int weedCount = 0; // 用于记录 weed 的计数
    int targetCount=0;//用于记录目标的总数

    int ret;
    rknn_app_context_t rknn_app_ctx;
    memset(&rknn_app_ctx, 0, sizeof(rknn_app_context_t));
    //作用是将类别存储在一个指针数组labels中，到时侯printf("识别结果: %s\n", labels[class_id]);输出: 识别结果: crop  或  识别结果: weed
    init_post_process();

    // 函数作用是，将结构体初始化，即将rknn的模型都输入进定义好的结构体rknn_app_context_t中，初始化rknn_app_ctx句柄
    ret = init_yolov8_model(model_path, &rknn_app_ctx);
    // 如果rknn模型初始化失败
    if (ret != 0)
    {
        printf("init_yolov8_model fail! ret=%d model_path=%s\n", ret, model_path);
        goto out;
    }

    //对图片进行转化操作
    image_buffer_t src_image;
    memset(&src_image, 0, sizeof(image_buffer_t));
    ret = read_image(image_path, &src_image);//将图片转化为 RKNN 推理所需要的形式存入src_image中,把"外部图像"转换成"程序内存中的像素数据"

#if defined(RV1106_1103)
    //RV1106 rga requires that input and output bufs are memory allocated by dma
    ret = dma_buf_alloc(RV1106_CMA_HEAP_PATH, src_image.size, &rknn_app_ctx.img_dma_buf.dma_buf_fd,
                        (void **) & (rknn_app_ctx.img_dma_buf.dma_buf_virt_addr));
    memcpy(rknn_app_ctx.img_dma_buf.dma_buf_virt_addr, src_image.virt_addr, src_image.size);
    dma_sync_cpu_to_device(rknn_app_ctx.img_dma_buf.dma_buf_fd);
    free(src_image.virt_addr);
    src_image.virt_addr = (unsigned char *)rknn_app_ctx.img_dma_buf.dma_buf_virt_addr;
    src_image.fd = rknn_app_ctx.img_dma_buf.dma_buf_fd;
    rknn_app_ctx.img_dma_buf.size = src_image.size;
#endif

    if (ret != 0)
    {
        printf("read image fail! ret=%d image_path=%s\n", ret, image_path);
        goto out;
    }

    object_detect_result_list od_results;// 目标检测结果列表结构体

    ret = inference_yolov8_model(&rknn_app_ctx, &src_image, &od_results);
    if (ret != 0)
    {
        printf("init_yolov8_model fail! ret=%d\n", ret);
        goto out;
    }

    // 画框和概率
    char text[256];
    for (int i = 0; i < od_results.count; i++)//判断出多少个，一一进行引用
    {
        object_detect_result *det_result = &(od_results.results[i]);
        printf("%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
               det_result->box.left, det_result->box.top,
               det_result->box.right, det_result->box.bottom,
               det_result->prop);
        int x1 = det_result->box.left;
        int y1 = det_result->box.top;
        int x2 = det_result->box.right;
        int y2 = det_result->box.bottom;

        //把原图像src_image放到函数里面进行画框，这里直接修改src_image图像，x2 - x1代表矩形宽度
        draw_rectangle(&src_image, x1, y1, x2 - x1, y2 - y1, COLOR_BLUE, 3);

        //并不是不能用qt的控件，只要不涉及ui的更新就行，存储要更新的数据是可以的
        // 获取目标类别名称
        QString className = QString::fromUtf8(coco_cls_to_name(det_result->cls_id));

        // 根据类名判断并更新计数器
        if (className == "crop") {
            cropCount++;
            targetCount++;
            sprintf(text, "%s %d %.1f%%", className.toUtf8().constData(), cropCount, det_result->prop * 100);
        } else if (className == "weed") {
            weedCount++;
            targetCount++;
            sprintf(text, "%s %d %.1f%%", className.toUtf8().constData(), weedCount, det_result->prop * 100);
        }

        // 将选项文本添加到 QStringList
        results.items.append(QString("%1 %2").arg(className).arg(i + 1));
        results.BOX.append(QString("%1").arg(det_result->prop * 100));
        // 将检测框坐标存储到 QList 中
        results.detectionBoxes.append(QRect(x1, y1, x2 - x1, y2 - y1));

        // 绘制文字
        draw_text(&src_image, text, x1, y1 - 30, COLOR_RED, 15);
    }
    //将总目标数量存储到结构体中
    results.targetsCount=targetCount;

    //write_image("out.png", &src_image);   //生成图片文件太耗时了，不结束还发不了信号


    /********************性能优化 BEGIN ************************/
    {
    // 替换原来的 write_image("out.png", &src_image);

    // 直接使用 OpenCV 数据创建 QImage（假设 src_image 是 BGR 格式）
    QImage resultImg(
        src_image.virt_addr,      // 直接使用原始数据指针
        src_image.width,          // 图像宽度
        src_image.height,         // 图像高度
        src_image.width * 3,      // 每行字节数（宽度*通道数）
        QImage::Format_BGR888     // OpenCV默认是BGR格式
        );

    // 转换为RGB格式（Qt需要RGB）
    QImage rgbImg = resultImg.rgbSwapped();
    results.img=rgbImg.copy();
    //直接对rgbImg拷贝再发送就行了(改写后面的)

    // 发送信号到主线程（零拷贝关键！）
    //emit detectionFinished(rgbImg);
    }
    /********************性能优化 END ************************/



out:
    deinit_post_process();

    ret = release_yolov8_model(&rknn_app_ctx);
    if (ret != 0)
    {
        printf("release_yolov8_model fail! ret=%d\n", ret);
    }

    if (src_image.virt_addr != NULL)
    {
#if defined(RV1106_1103)
        dma_buf_free(rknn_app_ctx.img_dma_buf.size, &rknn_app_ctx.img_dma_buf.dma_buf_fd,
                     rknn_app_ctx.img_dma_buf.dma_buf_virt_addr);
#else
        free(src_image.virt_addr);
#endif
    }
    return results; //返回纯数据
}

ImgDetectionWorker::receiveData ImgDetectionWorker::receiver(const QStringList &filelist,const QString &folderPath)
{
    return receivedata;
}

void ImgDetectionWorker::stop()
{
    QMutexLocker locker(&m_mutex);
    m_stop = true;
}

void ImgDetectionWorker::pause()
{
    m_pause = true;
}

void ImgDetectionWorker::next()
{
    m_pause = false;
}

