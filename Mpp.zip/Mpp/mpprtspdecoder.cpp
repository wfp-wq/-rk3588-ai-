#include "mpprtspdecoder.h"
#include <QDebug>



MppRtspDecoder::MppRtspDecoder(std::string url)
{
    this->url = url;
}

MppRtspDecoder::~MppRtspDecoder()
{
    qDebug() << "[MPP] 析构函数开始";
    release();  // 调用函数，释放mpp资源
    // 2. 释放 FFmpeg 资源
    if (av_packet) {
        av_packet_free(&av_packet);
        av_packet = NULL;
    }

    if (pFormatCtx) {
        avformat_close_input(&pFormatCtx);
        pFormatCtx = NULL;
    }

    // 3. 最后删除 data
    if (data) {
        delete data;
        data = NULL;
    }

    qDebug() << "[MPP] 析构函数结束";
}


int MppRtspDecoder::init()
{
    AVDictionary *options = NULL;// 创建一个字典，用来存放配置选项

    avformat_network_init(); // 初始化 FFmpeg 的网络模块（必须调用）
    av_dict_set(&options, "buffer_size", "1024000", 0); //设置缓存大小,1080p可将值跳到最大
    av_dict_set(&options, "rtsp_transport", "tcp", 0); //以tcp的方式打开,
    av_dict_set(&options, "stimeout", "5000000", 0);  //设置超时断开链接时间，单位us
    av_dict_set(&options, "max_delay", "500000", 0); //设置最大时延

    //FFmpeg 版的 malloc，专门用来在堆上分配一个 AVFormatContext 结构体的内存空间。
    pFormatCtx = avformat_alloc_context(); //用来申请AVFormatContext类型变量并初始化默认参数,申请的空间,

    //打开网络流或文件流,通过打开形式“options”和摄像头ip(url)，把返回结果存入pFormatCtx中
    if (avformat_open_input(&pFormatCtx, url.c_str(), NULL, &options) != 0)
    {
        printf("Couldn't open input stream.\n");
        return -1;
    }

    av_dict_free(&options);

    //获取视频文件信息，把获取的信息也存入pFormatCtx中
    if (avformat_find_stream_info(pFormatCtx, NULL)<0)
    {
        printf("Couldn't find stream information.\n");
        return -1;
    }


    //查找码流中是否有视频流
    video_stream_index = -1;
    unsigned i = 0;
    // 遍历所有流（pFormatCtx->nb_streams 是流的总数）
    for (i = 0; i<pFormatCtx->nb_streams; i++)
        // 判断当前流是不是视频流
        if (pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO)
        {
            printf("find video stream!\n");
            video_stream_index = i;
            break;
        }
    // 如果遍历完还是 -1，说明没有视频流
    if (video_stream_index == -1)
    {
        printf("Didn't find a video stream.\n");
        return -1;
    }

    // ========== 根据实际编码格式设置 type ==========
    AVCodecParameters *codecpar = pFormatCtx->streams[video_stream_index]->codecpar;
    MppCodingType type;

    if (codecpar->codec_id == AV_CODEC_ID_H264) {
        type = MPP_VIDEO_CodingAVC;
        printf("Using H.264 decoder\n");
    } else if (codecpar->codec_id == AV_CODEC_ID_HEVC) {
        type = MPP_VIDEO_CodingHEVC;
        printf("Using H.265 decoder\n");
    } else {
        printf("Unsupported codec: %d\n", codecpar->codec_id);
        return -1;
    }

    //在堆内存中申请一块空间，用来存放从 RTSP 流中读取的每一帧压缩视频数据。
    av_packet = (AVPacket *)av_malloc(sizeof(AVPacket)); // 申请空间，存放的每一帧数据 （h264、h265）

    // 初始化
    MPP_RET ret         = MPP_OK; // MPP 函数返回值，用于检查错误

    // base flow context
    MppCtx ctx          = NULL;   // MPP 解码器上下文（核心句柄）
    MppApi *mpi         = NULL;   // MPP 的 API 函数指针集合

    // input / output
    MppFrame  frame     = NULL;   // 解码后的视频帧

    MpiCmd mpi_cmd      = MPP_CMD_BASE; // 控制命令
    MppParam param      = NULL;         // 控制命令的参数
    RK_U32 need_split   = 1;            // 设置解码器为分片模式，1代表分片模式，允许把一帧数据分多次喂入，更适合网络流；0代表一次性喂所有数据
//    MppPollType timeout = 5;


    // resources
    size_t packet_size  = 8*1024; // 设置数据包缓冲区大小为 8KB
\
    data = new  MpiDecLoopData;   // 分配一个自定义结构体，存放解码循环需要的所有状态

    memset(data, 0, sizeof(MpiDecLoopData));

    ret = mpp_create(&ctx, &mpi);//拿到这个mpp的ctx和mpi

    if (MPP_OK != ret) {
        mpp_err("mpp_create failed\n");
        return -1;
    }

    // NOTE: decoder split mode need to be set before init
    mpi_cmd = MPP_DEC_SET_PARSER_SPLIT_MODE; //设置解析器处理输入，作用是把一块一块输入的数据拼成帧
    param = &need_split;                     //告诉 MPP 开启分片模式
    ret = mpi->control(ctx, mpi_cmd, param);
    if (MPP_OK != ret) {
        mpp_err("mpi->control failed\n");
        return -1;
    }

    mpi_cmd = MPP_SET_INPUT_BLOCK;           //设置输入接口，允许把帧分块输入MPP
    param = &need_split; // need_split=1
    ret = mpi->control(ctx, mpi_cmd, param);
    if (MPP_OK != ret) {
        mpp_err("mpi->control failed\n");
        return -1;
    }

    ret = mpp_init(ctx, MPP_CTX_DEC, type); //告诉 MPP 这个上下文用于解码（不是编码）
    if (MPP_OK != ret) {
        mpp_err("mpp_init failed\n");
        return -1;
    }

    // 发送 extradata (SPS/PPS)
    if (codecpar->extradata && codecpar->extradata_size > 0) {
        printf("Sending extradata: size=%d\n", codecpar->extradata_size);

        MppPacket ext_packet = NULL;
        ret = mpp_packet_init(&ext_packet, codecpar->extradata, codecpar->extradata_size);
        if (ret == MPP_OK) {
            ret = mpi->decode_put_packet(ctx, ext_packet);
            printf("decode_put_packet(extradata): ret=%d\n", ret);
            usleep(10000);
            mpp_packet_deinit(&ext_packet);
        }
    } else {
        printf("WARNING: No extradata found!\n");
    }

    data->ctx            = ctx;
    data->mpi            = mpi;
    data->eos            = 0;
    data->packet_size    = packet_size;
    data->frame          = frame;
    data->frame_count    = 0;

    return 0;
}

void MppRtspDecoder::release()
{
    qDebug() << "[MPP] 开始释放资源...";

    if (!data) {
        qDebug() << "[MPP] data 为空，无需释放";
        return;
    }

    //必须要先清空解码器内部缓冲区的所有帧，再去释放mpp资源，否则data->ctx释放资源会报错，这跟mpp内部变量调用有关
    // 步骤1：发送 EOS 停止解码器
    if (data->ctx && data->mpi) {
        qDebug() << "[MPP] 发送 EOS 包...";

        // 创建一个 EOS 包
        MppPacket eos_packet = NULL;
        mpp_packet_init(&eos_packet, NULL, 0);
        mpp_packet_set_eos(eos_packet);

        // 发送 EOS，相当于一个结束包
        data->mpi->decode_put_packet(data->ctx, eos_packet);
        mpp_packet_deinit(&eos_packet);

        // 等待 EOS 被处理
        qDebug() << "[MPP] 等待 EOS 处理...";
        QThread::msleep(100);

        // 步骤2：消费所有残留帧
        qDebug() << "[MPP] 消费残留帧...";
        MppFrame final_frame = NULL;
        int retry_count = 20;
        while (retry_count-- > 0) {
            MPP_RET ret = data->mpi->decode_get_frame(data->ctx, &final_frame);
            if (ret == MPP_OK && final_frame) {
                mpp_frame_deinit(&final_frame);
                final_frame = NULL;
            } else {
                break;
            }
            QThread::msleep(5);
        }

        // 步骤3：重置解码器到初始状态，方便待会释放
        qDebug() << "[MPP] 重置解码器...";
        data->mpi->reset(data->ctx);
        QThread::msleep(50);
    }

    // 步骤4：释放 MPP 相关资源（在重置之后）
    if (data->frame) {
        qDebug() << "[MPP] 释放 frame...";
        mpp_frame_deinit(&(data->frame));
        data->frame = NULL;
    }

    if (data->packet) {
        qDebug() << "[MPP] 释放 packet...";
        mpp_packet_deinit(&(data->packet));
        data->packet = NULL;
    }

    if (data->pkt_grp) {
        qDebug() << "[MPP] 清除 pkt_grp...";
        mpp_buffer_group_clear(data->pkt_grp);
        data->pkt_grp = NULL;
    }

    if (data->frm_grp) {
        qDebug() << "[MPP] 清除 frm_grp...";
        mpp_buffer_group_clear(data->frm_grp);
        data->frm_grp = NULL;
    }

    // 步骤5：最后销毁 ctx
    if (data->ctx) {
        qDebug() << "[MPP] 销毁 ctx...";
        mpp_destroy(data->ctx);
        data->ctx = NULL;
    }

    qDebug() << "[MPP] 资源释放完成";
}


void dump_mpp_frame_to_file(MppFrame frame, FILE *fp)
{
    RK_U32 width    = 0;
    RK_U32 height   = 0;
    RK_U32 h_stride = 0;
    RK_U32 v_stride = 0;

    MppBuffer buffer    = NULL;
    RK_U8 *base = NULL;

    width    = mpp_frame_get_width(frame);
    height   = mpp_frame_get_height(frame);
    h_stride = mpp_frame_get_hor_stride(frame);
    v_stride = mpp_frame_get_ver_stride(frame);
    buffer   = mpp_frame_get_buffer(frame);

    base = (RK_U8 *)mpp_buffer_get_ptr(buffer);
    RK_U32 buf_size = mpp_frame_get_buf_size(frame);
    size_t base_length = mpp_buffer_get_size(buffer);

    RK_U32 i;
    RK_U8 *base_y = base;
    RK_U8 *base_c = base + h_stride * v_stride;


    //保存为YUV420p格式
    for(i = 0; i < height; i++, base_y += h_stride)
    {
        fwrite(base_y, 1, width, fp);
    }
    for(i = 0; i < height * width / 2; i+=2)
    {
        fwrite((base_c + i), 1, 1, fp);
    }
    for(i = 1; i < height * width / 2; i+=2)
    {
        fwrite((base_c + i), 1, 1, fp);
    }
}

size_t mpp_buffer_group_usage(MppBufferGroup group)
{
    if (NULL == group)
    {
        mpp_err_f("input invalid group %p\n", group);
        return MPP_BUFFER_MODE_BUTT;
    }

    MppBufferGroupImpl *p = (MppBufferGroupImpl *)group;
    return p->usage;
}

// 放进去一帧，取出来一帧
int MppRtspDecoder::decode_simple( cv::Mat rgbImg )
{
    //局部变量初始化，为即将开始的 MPP 解码循环做准备。
    RK_U32 pkt_done = 0;
    RK_U32 pkt_eos  = 0;
    RK_U32 err_info = 0;
    MPP_RET ret = MPP_OK;
    MppCtx ctx  = data->ctx; //从 data 中取出 MPP 解码器上下文
    MppApi *mpi = data->mpi; //从 data 中取出 MPP API 函数指针
    // char   *buf = data->buf;
    MppPacket packet = NULL;
    MppFrame  frame  = NULL;

    if (av_read_frame(pFormatCtx, av_packet) < 0) // 从pFormatCtx视频流里，每次只读取这一帧放入av_packet堆内存中
    {
        printf("av_read_frame get packet failed!");
        return -1;
    }

    // ========== 过滤非视频流 ==========
    if (av_packet->stream_index != video_stream_index) {
        // printf("Skipping non-video packet (stream=%d)\n", av_packet->stream_index);
        av_packet_unref(av_packet);
        return 0;  // 返回0让调用者继续循环
    }

    ret = mpp_packet_init(&packet, av_packet->data, av_packet->size);//把 FFmpeg 读到的原始压缩数据"包装"成 MPP 解码器能识别的 MppPacket 格式。
    mpp_packet_set_pts(packet, av_packet->pts);//告诉 MPP 解码器这一帧应该在什么时间显示，保证视频播放的时序正确。

    do {
        RK_S32 times = 5;
        // send the packet first if packet is not done
        if (!pkt_done) {
            ret = mpi->decode_put_packet(ctx, packet);// 把压缩数据包喂给 MPP 解码器，ctx接收解码后的数据
            // printf("decode_put_packet: ret=%d, packet_size=%d\n", ret, av_packet->size);
            if (MPP_OK == ret)
                pkt_done = 1;
        }

        // then get all available frame and release
        do {
            RK_S32 get_frm = 0;// 标记这一轮是否成功获取到了帧（0=没拿到，1=拿到了）
            RK_U32 frm_eos = 0;// 标记获取到的帧是否是流的最后一帧（0=不是，1=是）

            try_again:
            //这里把ctx已经接收到的解码数据传给frame
            ret = mpi->decode_get_frame(ctx, &frame);//这里frame内部有标志位改变info_change_flag，默认为1，使其接收到的是参数包，只有参数。为0才为视频帧

            // printf("decode_get_frame returned: ret=%d, frame=%p\n", ret, frame);

            if (MPP_ERR_TIMEOUT == ret) {//MPP 解码器返回的超时错误码，表示数据还没准备
                if (times > 0) {//剩余重试次数，初始值为 5
                    times--;
                    msleep(1);
                    goto try_again;
                }
                mpp_err("decode_get_frame failed too much time\n");//解码器还没准备好，需要等待
            }
            if (MPP_OK != ret) {
                mpp_err("decode_get_frame failed ret %d\n", ret);//真正的错误（内存不足、参数错误等）
                break;
            }

            //开始分析解码后的帧
            if (frame) {
                //第一次传入的帧都是信息帧，从得到的帧中提取信息，把内存地址传给解码器，是为了让解码器把解码后的图像数据直接写入这块内存。
                if (mpp_frame_get_info_change(frame)) {
                    RK_U32 width = mpp_frame_get_width(frame);// 视频宽度
                    RK_U32 height = mpp_frame_get_height(frame);// 视频高度
                    RK_U32 hor_stride = mpp_frame_get_hor_stride(frame);// 水平对齐后的宽度
                    RK_U32 ver_stride = mpp_frame_get_ver_stride(frame);// 垂直对齐后的高度
                    RK_U32 buf_size = mpp_frame_get_buf_size(frame);// 每帧需要的缓冲区大小

                    mpp_log("decode_get_frame get info changed found\n");
                    mpp_log("decoder require buffer w:h [%d:%d] stride [%d:%d] buf_size %d",
                            width, height, hor_stride, ver_stride, buf_size);
                    ret = mpi->control(ctx, MPP_DEC_SET_INFO_CHANGE_READY, NULL);//改变解码器内部的 info_change_flag 状态，改变info_change_flag 为0
                    if (ret) {
                        mpp_err("info change ready failed ret %d\n", ret);
                        break;
                    }
                } else { //第二次传入的就是图像帧，进入else
                    err_info = mpp_frame_get_errinfo(frame) | mpp_frame_get_discard(frame);//合并两种信息，只要有一个非零，err_info 就非零
                    if (err_info) {
                        mpp_log("decoder_get_frame get err info:%d discard:%d.\n",
                                mpp_frame_get_errinfo(frame), mpp_frame_get_discard(frame));
                    }
                    data->frame_count++;
                    mpp_log("decode_get_frame get frame %d\n", data->frame_count);
                    YUV420SP2Mat(frame, rgbImg);// YUV → RGB
                   if (data->fp_output && !err_info){

                    //    cv::imwrite("./"+std::to_string(count++)+".jpg", rgbImg);

//                        dump_mpp_frame_to_file(frame, data->fp_output);
                   }
                }
                frm_eos = mpp_frame_get_eos(frame);//不是最后一帧输出0，是最后一帧输出1
                mpp_frame_deinit(&frame);//释放这个帧内存，为再次写入帧作准备

                frame = NULL;
                get_frm = 1;
            }

            // try get runtime frame memory usage
            if (data->frm_grp) {
                size_t usage = mpp_buffer_group_usage(data->frm_grp);// 查询当前内存使用量
                if (usage > data->max_usage)// 如果超过历史最大值
                    data->max_usage = usage;// 更新最大值
            }//监控 MPP 解码器实际使用的内存量，并记录下最大值，用于性能分析和调试。

            // 输入流已经结束（没有新数据了）,最后一个包已经喂给解码器,但这一帧不是最后一帧,就继续循环。如果是最后一帧，就不进入if
            if (pkt_eos && pkt_done && !frm_eos) { //这里有个问题，pkt_eos一直为0，永远不会进入if，这对于实时视频流无影响，对于本地文件检测会有影响
                msleep(10);
                continue;
            }
            // 检测到流结束时，退出内层解码循环。
            if (frm_eos) {//frm_eos=0，代表还不是最后一帧，if里面为0则不进入循环
                mpp_log("found last frame\n");
                break;
            }

            if (data->frame_num > 0 && data->frame_count >= data->frame_num) { //这里data在init()初始化,data->frame_num默认为0，只要视频流存在，就一直读下去，不进入if
                data->eos = 1;
                break;
            }

            if (get_frm)//只要还读取的到帧，就不会停止循环
                continue;
            break;
        } while (1); // 如果读到最后一帧就跳出循环，如果读到空帧也跳出循环

        if (data->frame_num > 0 && data->frame_count >= data->frame_num) {//这里data在init()初始化,data->frame_num默认为0，只要视频流存在，就一直读下去，不会进入if
            data->eos = 1;
            mpp_log("reach max frame number %d\n", data->frame_count);
            break;
        }

        if (pkt_done)
            break;

        msleep(1);
    } while (1);
    mpp_packet_deinit(&packet);//释放 packet 占用的资源，引用计数减 1
    if (av_packet != NULL)
        av_packet_unref(av_packet);//释放 av_read_frame 读取的这一帧压缩数据

    return ret;
}

void MppRtspDecoder::YUV420SP2Mat(MppFrame frame, cv::Mat rgbImg ) {
    // 1. 获取图像尺寸和 stride（硬件对齐后的宽度）
    RK_U32 width = mpp_frame_get_width(frame);
    RK_U32 height = mpp_frame_get_height(frame);
    RK_U32 h_stride = mpp_frame_get_hor_stride(frame); // 实际存储一行Y数据的宽度
    RK_U32 v_stride = mpp_frame_get_ver_stride(frame); // 实际存储Y数据的高度

    // 2. 获取 MPP 内部 buffer 指针
    MppBuffer buffer = mpp_frame_get_buffer(frame);
    RK_U8 *base = (RK_U8 *)mpp_buffer_get_ptr(buffer);

    // 3. 指向 Y 平面和 UV 平面
    RK_U8 *y_ptr = base;
    RK_U8 *uv_ptr = base + h_stride * v_stride;

    // 4. 创建 OpenCV 的 Mat 来包装 YUV 数据（注意这里是引用，不复制数据）
    cv::Mat yuvImg(height + height/2, h_stride, CV_8UC1, base);

    // 5. 【关键修正】：直接使用正确的转换公式 NV12 -> RGB
    //    注意 OpenCV 里 NV12 转 RGB 的正确颜色空间转换标志是 COLOR_YUV2RGB_NV12
    cv::cvtColor(yuvImg, rgbImg, cv::COLOR_YUV2RGB_NV12);

    // 6. 如果最终图像宽度和 stride 不一致，需要裁剪掉 padding 部分
    if (h_stride != width) {
        cv::Mat croppedImg = rgbImg(cv::Rect(0, 0, width, height));
        croppedImg.copyTo(rgbImg);
    }
}

