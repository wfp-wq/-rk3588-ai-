#include "mpprtspdecoder.h"
#include <cstdio>
#include <string>
#include <iostream>

#include <chrono>  // 用于时间计算

using namespace std::chrono;

using namespace std;

void MppDecoder_execute()
{
    string path3 ="rtsp://admin:S1234567890@192.168.1.2:554/1/1";
    MppRtspDecoder *mppdec = new MppRtspDecoder{path3};
    mppdec->init();
    //cv::Mat imgshow;

    int count = 0;
    double cost_all = 0;

    cv::Mat img;
    img.create(cv::Size(1280,720), CV_8UC3); //70fps解码

    while (1)
    {
        auto start = std::chrono::system_clock::now();
        mppdec->decode_simple(img);
        count++;

        auto finish = std::chrono::system_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(finish-start);
        cost_all += (double)duration.count();

        printf("frame: %d, cost: %f, avg_cost: %f\n", count, (double)duration.count(), cost_all/count);
        printf("cols:%d\n", img.cols);
        if ( img.empty() )
        {
            printf("img is empty\n");
            continue;
        }

        // cv::resize(img, imgshow, cv::Size{1280,720});
        // cv::imshow("  ", imgshow);
        // cv::waitKey(1);
    }
}
