#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTextEdit>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include<QString>
#include<QFileDialog>
#include<QMessageBox>
#include<QThread>
#include<QDebug>
#include<QComboBox>
#include<QStringList>
#include<QPointer>  //美化提示框需要
#include<QTimer>
#include<QPropertyAnimation> //美化提示框需要
#include<QMetaObject>
#include<serialwindow.h>
#include <QProcess>
#include <QEventLoop>
#include "yolov8_img/yolov8.h"
#include "camThread_test/cam_thread.h"
#include "img_thread.h"
#include "Peripherals/duoji/duoji.h"
#include "dynamic_FireTime_thread.h"
//#include "Peripherals/RTSP_Camera/rtsp_camera.h"
#include "Daemon_Thread.h"

class other_functions;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void delayMs(int ms);
    void Map_and_Send();
    void showImageLabel();

private:
    //其他页面
    SerialWindow *s;    //串口界面
    other_functions *s2; //其他功能界面


    QPointer<QLabel> floatingMessageLabel; //用于显示浮动提示信息的标签
    QString folderPath;
    int currentImageIndex; // 新增：当前检测的图片索引

    //子线程任务
    QThread workerThread;//全局线程，定义为对象，不定义指针
    CamThread *camThread;//实时检测任务
    ImgDetectionWorker *imgDetectionWorker;//图片检测任务
    DaemonThread *daemonthread; //后台任务

    QLabel *title;
    QLabel *imageLabel;
    QComboBox *detectionBoxComboBox;
    QPushButton *openImageBtn;
    QPushButton *openFolderBtn;
    QPushButton *openCameraBtn;
    QPushButton *closeImageBtn;
    QPushButton *pauseFolderBtn;
    QPushButton *configSerialBtn; //切换串口界面按钮
    QPushButton *otherFunctionsBtn; //切换其他功能界面按钮
    QLabel *xminText,*xmaxText,*yminText,*ymaxText;
    QLabel *xmin,*xmax,*ymin,*ymax;
    QLabel *xzText,*yzText;
    QLabel *zx,*zy; //检测框中心
    QLabel *ZAP_xmText,*ZAP_ymText;
    QLabel *ZAP_xm,*ZAP_ym;
    QLabel *totalTargetsCount;
    QLabel *Box;//置信度的值
    QMetaObject::Connection m_comboConnection;//管理lambda形式的槽函数的生命周期

    //标志位
    bool isimageopen,isfolderopen,isCameraOpen,ispause;
    bool isLastHandle_m;
    bool isCloseHandle;
    bool isFinished;
    bool image_mkdir_test;
    bool test_over;

    int x,y;//中心点坐标
    DuoJi *duoji;

private slots:
    void onOpenCameraBtnClicked();
    void onOpenImageBtnClicked();
    void handleResults(DetectionResults results);//槽函数，用于接收线程发送的信号
    void handleResults(QImage img,DetectionResults results);//重载，这个是给摄像头子线程用的
    void onOpenFolderBtnClicked();
    void showFloatingMessage(const QString& message,int timeout); //美化版本
    void onCloseImageBtnClicked();
    void onPauseFolderBtnClicked();//暂停文件夹检测函数
    void isImgDetectionFinished();
    void onOtherFunctionsBtnClicked(); //功能：切换到其他功能界面
    void handleLastResults(bool isLastHandle);
    void showSerialFullScreen();
    void showMainWindowFullScreen();
    void showOtherFunctionUIFullScreen();

signals:
    void send(const QStringList &filelist,const QString &folderPath);
    void start_Acc();
    void danzhou_move_send(QByteArray hexByte);
    void stop();
    void reStart();
};

#endif // MAINWINDOW_H
