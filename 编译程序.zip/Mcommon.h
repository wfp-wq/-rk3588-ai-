#ifndef MCOMMON_H
#define MCOMMON_H

#include <QObject>
#include <QThread>
#include <QMutex>
#include<QImage>
#include<QElapsedTimer>
#include<QMutexLocker>
#include <QVector>
#include<QRunnable>
#include <QMetaType>
#include <QWaitCondition>
#include <QEventLoop>
#include <QCoreApplication>
#include <QDateTime>
#include <QTimer>
#include <QDebug>
#include <QDir>
#include <QThreadPool>
#include <QQueue>
#include <QRunnable>
#include <opencv2/opencv.hpp>
#include "image_utils.h"
#include "file_utils.h"
#include "image_drawing.h"
#include "yolov8_img/yolov8.h"

//此文件都是共享资源（谁都可以拿来用并作出修改）
//结构体是声明
struct FrameData{
    std::shared_ptr<cv::Mat> frame;  // 改为共享指针
    int current_frame;
    int frame_count;
    qint64 sendTime;//表示的是ms，所以用int无所谓
};

//必须是声明，不能定义

Q_DECLARE_METATYPE(cv::Mat)
Q_DECLARE_METATYPE(FrameData) // 声明元类型
Q_DECLARE_METATYPE(FrameData*)
Q_DECLARE_METATYPE(QSharedPointer<FrameData>)

#endif // MCOMMON_H
