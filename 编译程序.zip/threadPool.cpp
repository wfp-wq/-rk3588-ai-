#include "threadPool.h"


//当前颜色显示异常是因为当前颜色设置是给Qt的窗口用的，但是现在显示用的是opencv窗口
Inference::Inference(FrameData m_frameData, rknn_app_context_t m_rknn_app_ctx, int m_ret)
    : frameData(m_frameData)
    , rknn_app_ctx(m_rknn_app_ctx)
    , ret(m_ret)
    , lower_green(35, 50, 50)    // 初始化绿色范围
    , upper_green(85, 255, 255)
{
    setAutoDelete(true);
}

GreenResult Inference::doGreenDetect(cv::Mat frame)
{
    GreenResult result;
    result.max_area = 0;
    result.weed_count = 0;

    // ✅ 使用成员变量，不要重新创建
    cv::cvtColor(frame, hsv, cv::COLOR_RGB2HSV);
    cv::inRange(hsv, lower_green, upper_green, green_mask);

    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(9, 9));
    cv::morphologyEx(green_mask, green_mask, cv::MORPH_OPEN, kernel);

    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(green_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    for (const auto& contour : contours) {
        double area = cv::contourArea(contour);
        if (area > 200) {
            cv::Rect weed_rect = cv::boundingRect(contour);
            result.all_weeds.push_back(weed_rect);
            result.weed_count++;
            if (area > result.max_area) {
                result.max_area = area;
                result.best_weed = weed_rect;
            }
        }
    }
    result.green_mask = green_mask;  // 成员变量赋值给结果

    return result;
}

void Inference::run()
{
    printf("========== Inference::run() START ==========\n");
    DetectionResults results;
    int cropCount = 0;
    int weedCount = 0;
    int targetCount = 0;

    qDebug() << "线程池正在工作中...";
    image_buffer_t src_image;
    memset(&src_image, 0, sizeof(image_buffer_t));
    object_detect_result_list od_results;

    double fps = 0.0;
    timer.start();

    // ========== 获取图像引用 ==========
    cv::Mat& frame = *(frameData.frame);
    if(frame.empty()) {
        qDebug() << "空帧";
        return;
    }

    cv::resize(frame, frame, cv::Size(720, 720));
    cv::cvtColor(frame, frame, cv::COLOR_BGR2RGB);
    src_image.height = frame.rows;
    src_image.width = frame.cols;
    src_image.width_stride = frame.step[0];
    src_image.virt_addr = frame.data;
    src_image.format = IMAGE_FORMAT_RGB888;
    src_image.size = frame.total() * frame.elemSize();

    int ret;
    image_buffer_t dst_img;
    letterbox_t letter_box;
    rknn_input inputs[rknn_app_ctx.io_num.n_input];
    rknn_output outputs[rknn_app_ctx.io_num.n_output];
    const float nms_threshold = NMS_THRESH;
    const float box_conf_threshold = BOX_THRESH;
    int bg_color = 114;

    memset(&od_results, 0x00, sizeof(od_results));
    memset(&letter_box, 0, sizeof(letterbox_t));
    memset(&dst_img, 0, sizeof(image_buffer_t));
    memset(inputs, 0, sizeof(inputs));
    memset(outputs, 0, sizeof(outputs));

    dst_img.width = rknn_app_ctx.model_width;
    dst_img.height = rknn_app_ctx.model_height;
    dst_img.format = IMAGE_FORMAT_RGB888;
    dst_img.size = get_image_size(&dst_img);
    dst_img.virt_addr = (unsigned char *)malloc(dst_img.size);
    if (dst_img.virt_addr == NULL) {
        printf("malloc buffer size:%d fail!\n", dst_img.size);
        return;
    }

    ret = convert_image_with_letterbox(&src_image, &dst_img, &letter_box, bg_color);
    if (ret < 0) {
        printf("convert_image_with_letterbox fail! ret=%d\n", ret);
        free(dst_img.virt_addr);
        return;
    }

    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].size = rknn_app_ctx.model_width * rknn_app_ctx.model_height * rknn_app_ctx.model_channel;
    inputs[0].buf = dst_img.virt_addr;

    ret = rknn_inputs_set(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_input, inputs);
    if (ret < 0) {
        printf("rknn_input_set fail! ret=%d\n", ret);
        free(dst_img.virt_addr);
        return;
    }
    free(dst_img.virt_addr);

    // ========== 复制一份图像用于绿色检测（异步并行）==========
    cv::Mat frame_for_green = frame.clone();

    // 启动异步绿色检测（在另一个线程执行）
    QFuture<GreenResult> greenFuture = QtConcurrent::run([this, frame_for_green]() {
        return doGreenDetect(frame_for_green);
    });

    // ========== 同时进行 NPU 推理 ==========
    printf("rknn_run\n");
    ret = rknn_run(rknn_app_ctx.rknn_ctx, nullptr);
    if (ret < 0) {
        printf("rknn_run fail! ret=%d\n", ret);
        return;
    }

    memset(outputs, 0, sizeof(outputs));
    for (int i = 0; i < rknn_app_ctx.io_num.n_output; i++) {
        outputs[i].index = i;
        outputs[i].want_float = (!rknn_app_ctx.is_quant);
    }
    ret = rknn_outputs_get(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_output, outputs, NULL);

    post_process(&rknn_app_ctx, outputs, &letter_box, box_conf_threshold, nms_threshold, &od_results);
    rknn_outputs_release(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_output, outputs);

    // ========== 等待绿色检测完成 ==========
    GreenResult greenResult = greenFuture.result();

    // ========== 收集农作物框 ==========
    std::vector<cv::Rect> crop_boxes;
    for (int i = 0; i < od_results.count; i++) {
        object_detect_result* det_result = &(od_results.results[i]);
        QString className = QString::fromUtf8(coco_cls_to_name(det_result->cls_id));
        if (className == "crop") {
            cv::Rect crop_rect(
                det_result->box.left,
                det_result->box.top,
                det_result->box.right - det_result->box.left,
                det_result->box.bottom - det_result->box.top
                );
            crop_boxes.push_back(crop_rect);
            cropCount++;
        }
    }
    // ========== 画杂草框（排除农作物区域）==========
    int valid_weed_count = 0;
    cv::Rect final_best_weed;
    double final_max_area = 0;

    for (const auto& weed_rect : greenResult.all_weeds) {
        bool is_in_crop = false;
        for (const auto& crop_rect : crop_boxes) {
            cv::Rect intersect = weed_rect & crop_rect;
            if (intersect.area() > 0) {
                is_in_crop = true;
                break;
            }
        }
        if (!is_in_crop) {
            valid_weed_count++;
            double area = weed_rect.width * weed_rect.height;
            if (area > final_max_area) {
                final_max_area = area;
                final_best_weed = weed_rect;
            }
            // 画杂草框（红色）
            draw_rectangle(&src_image, weed_rect.x, weed_rect.y,
                           weed_rect.width, weed_rect.height, 0xFF0000, 2);
            char weed_text[256];
            sprintf(weed_text, "weed %d", valid_weed_count);
            draw_text(&src_image, weed_text, weed_rect.x, weed_rect.y - 20, 0xFF0000, 10);
        }
    }

    // 发送最大的杂草坐标
    if (final_max_area > 0) {
        target_x = final_best_weed.x + final_best_weed.width / 2;
        target_y = final_best_weed.y + final_best_weed.height / 2;
    }

    results.targetsCount = cropCount + valid_weed_count;

    cv::Mat result_mat = cv::Mat(src_image.height, src_image.width, CV_8UC3, src_image.virt_addr, src_image.width_stride);

    fps = 1 * 1000.0 / timer.elapsed();
    qDebug() << "推理时间:" << timer.elapsed() << "ms";
    qDebug() << "推理FPS:" << fps;
    timer.restart();

    cv::putText(result_mat,
                cv::format("Frame: %d/%d", frameData.current_frame, frameData.frame_count),
                cv::Point(10, 120), cv::FONT_HERSHEY_SIMPLEX,
                2, cv::Scalar(0, 0, 255), 6);

    frame = result_mat.clone();
    emit send(frameData, results);

    // 重置计数器
    targetCount = 0;
    cropCount = 0;
    weedCount = 0;
    results.detectionBoxes.clear();
    results.items.clear();
    results.BOX.clear();

    return;
}


