#include "mainwindow.h"
#include "serialwindow.h"
#include "Mcommon.h"

#include <QApplication>
#include<QFile>

int main(int argc, char *argv[])
{
    // -------------------------运行到这里0000----------------------
    qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard")); //软键盘环境
    /*
    *QApplication 在构造时会初始化 Qt 的输入方法系统（包括读取 QT_IM_MODULE 环境变量）
    *，并根据该变量的值加载对应的输入模块（如虚拟键盘）。
    */

    //setlocale(LC_ALL, "C");
    QApplication a(argc, argv);


    // -------------------------运行到这里99999----------------------
    // 注册自定义类型（必须在使用前调用）
    qRegisterMetaType<cv::Mat>("cv::Mat"); //必须在FrameData前注册
    qRegisterMetaType<FrameData>("FrameData");
    qRegisterMetaType<FrameData*>("FrameData*");
    qRegisterMetaType<QSharedPointer<FrameData>>("QSharedPointer<FrameData>");

    // -------------------------运行到这里----------------------
    QFile file(":/style.qss");
    if(file.exists())
    {
        file.open(QFile::ReadOnly);
        QString styleSheet =QLatin1String(file.readAll());
        qApp->setStyleSheet(styleSheet);
        file.close();
    }
    // -------------------------运行到这里1----------------------
    MainWindow w;
    // -------------------------运行到这里2----------------------
    w.show();
    //SerialWindow s;
    //s.show();
    return a.exec();
}
