/*-------------------------------------------
                Includes
-------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*-------------------------------------------
                  Main Function
-------------------------------------------*/

#include "video_inference.h"
#include <QDebug>

VideoInference::VideoInference(QObject *parent) : QObject(parent), m_stop(false)
{
}

VideoInference::~VideoInference()
{
    stop();
}

void VideoInference::stop()
{
    QMutexLocker locker(&m_mutex);
    m_stop = true;
}

void VideoInference::Inference(FrameData frameData)
{
    qDebug()<<"二线程正在工作中...";
    const char *model_path = "./model/yolov8.rknn";

    int ret;
    rknn_app_context_t rknn_app_ctx;
    memset(&rknn_app_ctx, 0, sizeof(rknn_app_context_t));

    init_post_process();

    ret = init_yolov8_model(model_path, &rknn_app_ctx);
    if (ret != 0)
    {
        printf("init_yolov8_model fail! ret=%d model_path=%s\n", ret, model_path);
    }

    image_buffer_t src_image;
    memset(&src_image, 0, sizeof(image_buffer_t));
    object_detect_result_list od_results;

    //QElapsedTimer timer;
    double fps=0.0;
    timer.start(); // 开始计时

    //颜色转换的正确位置
    // cv::cvtColor(frameData.frame, frameData.frame, cv::COLOR_BGR2RGB);
    // cv::rotate(frameData.frame, frameData.frame, cv::ROTATE_90_COUNTERCLOCKWISE); //旋转画面，可以用RGA做其实
    // src_image.height = frameData.frame.rows;
    // src_image.width = frameData.frame.cols;
    // src_image.width_stride = frameData.frame.step[0];
    // src_image.virt_addr = frameData.frame.data;
    // src_image.format = IMAGE_FORMAT_RGB888;
    // src_image.size = frameData.frame.total() * frameData.frame.elemSize();

    //int ret;  //之前这个ret是while的局部变量
    image_buffer_t dst_img;
    letterbox_t letter_box;
    rknn_input inputs[rknn_app_ctx.io_num.n_input];
    rknn_output outputs[rknn_app_ctx.io_num.n_output];
    const float nms_threshold = NMS_THRESH;      // 默认的NMS阈值
    const float box_conf_threshold = BOX_THRESH; // 默认的置信度阈值
    int bg_color = 114;

    memset(&od_results, 0x00, sizeof(od_results));
    memset(&letter_box, 0, sizeof(letterbox_t));
    memset(&dst_img, 0, sizeof(image_buffer_t));
    memset(inputs, 0, sizeof(inputs));
    memset(outputs, 0, sizeof(outputs));

    // Pre Process
    dst_img.width = rknn_app_ctx.model_width;
    dst_img.height = rknn_app_ctx.model_height;
    dst_img.format = IMAGE_FORMAT_RGB888;
    dst_img.size = get_image_size(&dst_img);
    dst_img.virt_addr = (unsigned char *)malloc(dst_img.size);
    if (dst_img.virt_addr == NULL)
    {
        printf("malloc buffer size:%d fail!\n", dst_img.size);
        return;
    }

    // letterbox
    ret = convert_image_with_letterbox(&src_image, &dst_img, &letter_box, bg_color);
    if (ret < 0)
    {
        printf("convert_image_with_letterbox fail! ret=%d\n", ret);
        return;
    }

    // Set Input Data
    inputs[0].index = 0;
    inputs[0].type = RKNN_TENSOR_UINT8;
    inputs[0].fmt = RKNN_TENSOR_NHWC;
    inputs[0].size = rknn_app_ctx.model_width * rknn_app_ctx.model_height * rknn_app_ctx.model_channel;
    inputs[0].buf = dst_img.virt_addr;

    ret = rknn_inputs_set(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_input, inputs);
    if (ret < 0)
    {
        printf("rknn_input_set fail! ret=%d\n", ret);
        return;
    }
    free(dst_img.virt_addr);
    // Run
    printf("rknn_run\n");
    ret = rknn_run(rknn_app_ctx.rknn_ctx, nullptr);
    if (ret < 0)
    {
        printf("rknn_run fail! ret=%d\n", ret);
        return;
    }

    // Get Output
    memset(outputs, 0, sizeof(outputs));
    for (int i = 0; i < rknn_app_ctx.io_num.n_output; i++)
    {
        outputs[i].index = i;
        outputs[i].want_float = (!rknn_app_ctx.is_quant);
    }
    ret = rknn_outputs_get(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_output, outputs, NULL);


    // Post Process
    post_process(&rknn_app_ctx, outputs, &letter_box, box_conf_threshold, nms_threshold, &od_results);

    // Remeber to release rknn output
    rknn_outputs_release(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_output, outputs);

    // 画框和概率
    char text[256];
    for (int i = 0; i < od_results.count; i++)
    {
        object_detect_result *det_result = &(od_results.results[i]);
        printf("%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
               det_result->box.left, det_result->box.top,
               det_result->box.right, det_result->box.bottom,
               det_result->prop);
        int x1 = det_result->box.left;
        int y1 = det_result->box.top;
        int x2 = det_result->box.right;
        int y2 = det_result->box.bottom;

        draw_rectangle(&src_image, x1, y1, x2 - x1, y2 - y1, COLOR_BLUE, 3);
        sprintf(text, "%s %.1f%%", coco_cls_to_name(det_result->cls_id), det_result->prop * 100);
        draw_text(&src_image, text, x1, y1 - 20, COLOR_GREEN, 10);
    }


    cv::Mat result_mat = cv::Mat(src_image.height, src_image.width, CV_8UC3, src_image.virt_addr, src_image.width_stride);

    //计算FPS
    fps = 1 * 1000.0/(timer.elapsed()+frameData.sendTime);
    timer.restart();

    cv::putText(result_mat, cv::format("Actual FPS: %.1f FPS", fps),
                cv::Point(10, 60), cv::FONT_HERSHEY_SIMPLEX,
                2, cv::Scalar(0, 0, 255), 6);
    qDebug()<<fps;

    cv::putText(result_mat,
                cv::format("Frame: %d/%d", frameData.current_frame, frameData.frame_count),
                cv::Point(10, 120), cv::FONT_HERSHEY_SIMPLEX,
                2, cv::Scalar(0, 0, 255), 6);

    qDebug()<<"ERROR:立刻就能到这里AAA！";//即便是多线程，点击的瞬间也能从A线程跑到这里

    // frameData.frame=result_mat;

    emit send(frameData);

    deinit_post_process();

    ret = release_yolov8_model(&rknn_app_ctx);  //反正帧已经加工好并发过去了，释放模型资源也无所谓了
    if (ret != 0)
    {
        printf("release_yolov8_model fail! ret=%d\n", ret);
    }
    m_stop=false;
    //是因为下面的内容导致内存被连续释放两次
    // if (src_image.virt_addr != NULL)
    // {
    //     free(src_image.virt_addr);
    // }
    return;
}
