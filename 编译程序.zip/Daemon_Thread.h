#ifndef DAEMON_THREAD_H
#define DAEMON_THREAD_H

#include <QObject>
#include "Peripherals/serialport/serialport.h"
#include "Peripherals/RTSP_Camera/rtsp_camera.h"
#include "animation/wait_animation.h"

class DaemonThread : public QObject
{
    Q_OBJECT

public: //不写public默认方法是private
    explicit DaemonThread(QObject *parent= nullptr);
    ~DaemonThread();

public slots:
    void Map_and_Move(int target_x);
    void danzhou_init_receive();
    void danzhou_test_0();
    void danzhou_test_1();
    void danzhou_test_2();
    void danzhou_test_3();
    void danzhou_test_4();
    void danzhou_Factory_reset();

public:
    SerialPort *serialport;
    RTSP_Camera *rtsp_camera;
    Wait_Animation *wait_animation;

    bool isFinished;
};

#endif // DAEMON_THREAD_H
