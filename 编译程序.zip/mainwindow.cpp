#include "mainwindow.h"
#include "img_thread.h"
#include "debug_test_ui.h"
#include "QThreadPool"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),isimageopen(false),isfolderopen(false),isCameraOpen(false),ispause(false),isLastHandle_m(false)
    ,isCloseHandle(false),isFinished(false),image_mkdir_test(false),test_over(false)
{
/************************ 界面UI布局 BEGIN ************************/
//主布局
    setWindowTitle("WEEDZAP");//窗口标题
    //显示模式
    //this->setGeometry(0,0,640,480); //窗口调试
    showFullScreen(); //全屏显示
    //中心部件设置
    QWidget *centralWidget = new QWidget(this); //创建中心部件
    setCentralWidget(centralWidget); //必须设置中心容器，否则布局不生效
    centralWidget->setObjectName("centralWidget"); //用于qss样式表
    //中心布局设置(主布局)
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget); //中心布局：垂直布局，创建一个垂直布局管理器，并立即把它“安装”到 centralWidget 这个控件上
    mainLayout->setContentsMargins(0, 0, 0, 0); //移除中心容器和窗口的间距
    mainLayout->setSpacing(1); //去除布局间距

//标题布局(先添加容器，再添加布局，最后再在布局里加东西，然后将容器整个放进去主布局)
    //标题容器设置
    QWidget *titleContainer=new QWidget();//在后面addWidget()函数设置父对象
    titleContainer->setObjectName("titleContainer");
    titleContainer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);//第一个参数是水平方向，第二个是垂直方向，Expanding代表岁窗口延展，Preferred代表不随窗口延展
    titleContainer->setFixedHeight(100);
    //标题容器布局设置
    QHBoxLayout *titleLayout=new QHBoxLayout(titleContainer);//水平布局,创造一个水平布局，并且把他安装到titleContainer容器上上
    QLabel *titleText=new QLabel("基于RK3588的激光除草系统");
    //添加到标题容器布局
    titleLayout->addWidget(titleText,0,Qt::AlignHCenter);
    //添加到主布局
    mainLayout->addWidget(titleContainer);//给titleContainer设置父对象mainLayout,把标题添加到垂直布局上

//主内容布局
    //主内容容器设置
    QWidget *contentContainer=new QWidget();
    contentContainer->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    //主内容容器布局设置
    QHBoxLayout *contentLayout = new QHBoxLayout(contentContainer);
    contentLayout->setSpacing(1);
    //添加到主布局
    mainLayout->addWidget(contentContainer);

//主内容——左半部分布局
    //主内容——左半部分容器设置
    QWidget *containerA=new QWidget();
    containerA->setFixedWidth(1200);
    containerA->setFixedHeight(900);
    //主内容——左半部分容器布局设置
    QVBoxLayout *leftcontentLayout =new QVBoxLayout(containerA);
    //加载默认图片
    QPixmap pixmap(":icons/template.jpg");
    imageLabel = new QLabel(centralWidget); //初始化 imageLabel
    if (!pixmap.isNull()) { //如果图片不是空的,即图片加载成功
        imageLabel->setPixmap(pixmap.scaled(1200, 700, Qt::IgnoreAspectRatio)); // 直接设置缩放大小
        imageLabel->setAlignment(Qt::AlignLeft);
        imageLabel->setAlignment(Qt::AlignTop);
        // 图片顶部显示 #如果设置AlignCenter的话，图片距离顶端可能会有间距
    } else {
        imageLabel->setText("默认图片加载失败");
        imageLabel->setAlignment(Qt::AlignCenter); // 文字居中显示
    }

    //添加到左半部分容器
    leftcontentLayout->addWidget(imageLabel); // 将图片标签添加到布局
    contentLayout->addWidget(containerA);


//左半部分——下半部分——按钮部分布局
    //左半部分——下半部分——按钮部分容器设置
    QWidget *leftBottomContainer=new QWidget();
    //左半部分——下半部分——按钮部分容器布局设置
    QVBoxLayout *leftBottomLayout=new QVBoxLayout(leftBottomContainer);
    QHBoxLayout *leftButtonLayout=new QHBoxLayout();
    openImageBtn=new QPushButton("图片",leftBottomContainer);
    openFolderBtn=new QPushButton("文件夹",leftBottomContainer);
    openCameraBtn=new QPushButton("摄像头",leftBottomContainer);
    QHBoxLayout *controllLayout=new QHBoxLayout();
    closeImageBtn=new QPushButton("关闭图片",leftBottomContainer);
    pauseFolderBtn=new QPushButton("暂停",leftBottomContainer);
    //configSerialBtn=new QPushButton("配置串口",leftBottomContainer);
    otherFunctionsBtn=new QPushButton("调试界面",leftBottomContainer);
    controllLayout->addWidget(closeImageBtn);
    controllLayout->addWidget(pauseFolderBtn);
    controllLayout->addWidget(otherFunctionsBtn);
    leftButtonLayout->addWidget(openImageBtn);
    leftButtonLayout->addWidget(openFolderBtn);
    leftButtonLayout->addWidget(openCameraBtn);
    leftBottomLayout->addLayout(leftButtonLayout);
    leftBottomLayout->addLayout(controllLayout);

    //添加到左半部分容器
    leftcontentLayout->addWidget(leftBottomContainer);

    //主内容_右半部分布局
    QWidget *containerB=new QWidget();
    containerB->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    QVBoxLayout *rightcontentLayout =new QVBoxLayout(containerB);


    //右半部分_上半部分布局
    QWidget *rightTopContainer=new QWidget();
    rightTopContainer->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);
    rightTopContainer->setFixedHeight(200);
    QVBoxLayout *rightTopLayout=new QVBoxLayout(rightTopContainer);
    QLabel *BOX_Text=new QLabel("置信度阈值");
    QLabel *NMS_Text=new QLabel("交互比阈值");
    BOX_Text->setAlignment(Qt::AlignLeft);
    NMS_Text->setAlignment(Qt::AlignLeft);
    rightTopLayout->addWidget(BOX_Text,0,Qt::AlignTop);
    rightTopLayout->addWidget(NMS_Text,0,Qt::AlignTop);

    //右半部分_下半部分布局
    QWidget *rightBottomContainer=new QWidget();
    rightBottomContainer->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);
    QVBoxLayout *rightBottomLayout=new QVBoxLayout(rightBottomContainer);
    rightBottomLayout->setSpacing(0);
    QHBoxLayout *totalTargetsLayout=new QHBoxLayout();
    QLabel *totalTargets=new QLabel("总目标数: ");
    totalTargetsCount=new QLabel("");
    totalTargetsLayout->addWidget(totalTargets);
    totalTargetsLayout->addWidget(totalTargetsCount,Qt::AlignLeft);
    QLabel *spendTime=new QLabel("用时");
    QHBoxLayout *targetsChooseLayout=new QHBoxLayout();
    QLabel *targetsChoose=new QLabel("目标选择");
    detectionBoxComboBox=new QComboBox();
    detectionBoxComboBox->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Fixed);
    detectionBoxComboBox->setFixedHeight(50);
    detectionBoxComboBox->addItem("默认一");
    detectionBoxComboBox->addItem("默认二");
    targetsChooseLayout->addWidget(targetsChoose);
    targetsChooseLayout->addWidget(detectionBoxComboBox);
    QLabel *spcices=new QLabel("类型");
    QHBoxLayout *BoxLayout=new QHBoxLayout();
    QLabel *NMS=new QLabel("置信度: ");
    Box=new QLabel("");
    BoxLayout->addWidget(NMS);
    BoxLayout->addWidget(Box,Qt::AlignLeft);
    rightBottomLayout->addLayout(totalTargetsLayout);
    rightBottomLayout->addWidget(spendTime,0,Qt::AlignTop);
    rightBottomLayout->addLayout(targetsChooseLayout);
    rightBottomLayout->addWidget(spcices,0,Qt::AlignTop);
    rightBottomLayout->addLayout(BoxLayout);

    //添加到右半部分容器
    rightcontentLayout->addWidget(rightTopContainer);
    rightcontentLayout->addWidget(rightBottomContainer);
    contentLayout->addWidget(containerB);

    //坐标信息
    QWidget *coordinateContainer=new QWidget();
    QVBoxLayout *coordinateLayout=new QVBoxLayout(coordinateContainer);
    rightBottomLayout->addWidget(coordinateContainer);
    QLabel *locationTitle=new QLabel("目标位置");
    coordinateLayout->addWidget(locationTitle);
    QHBoxLayout *xcoordinateLayout=new QHBoxLayout();
    QHBoxLayout *ycoordinateLayout=new QHBoxLayout();
    QHBoxLayout *middleCoordinateLayout=new QHBoxLayout();
    QHBoxLayout *ZAP_middleCoordinateLayout=new QHBoxLayout();
    coordinateLayout->addLayout(xcoordinateLayout);
    coordinateLayout->addLayout(ycoordinateLayout);
    coordinateLayout->addLayout(middleCoordinateLayout);
    coordinateLayout->addLayout(ZAP_middleCoordinateLayout);
    xminText=new QLabel("xmin: ");
    xmaxText=new QLabel("xmax: ");
    yminText=new QLabel("ymin: ");
    ymaxText=new QLabel("ymax: ");
    xzText=new QLabel("杂草x: ");
    yzText=new QLabel("杂草y: ");
    ZAP_xmText=new QLabel("激光x: ");
    ZAP_ymText=new QLabel("激光y: ");
    xmin=new QLabel("");
    xmax=new QLabel("");
    ymin=new QLabel("");
    ymax=new QLabel("");
    zx=new QLabel("");
    zy=new QLabel("");
    ZAP_xm=new QLabel("");
    ZAP_ym=new QLabel("");
    xcoordinateLayout->addWidget(xminText);
    xcoordinateLayout->addWidget(xmin,Qt::AlignLeft);
    ycoordinateLayout->addWidget(yminText);
    ycoordinateLayout->addWidget(ymin,Qt::AlignLeft);
    xcoordinateLayout->addWidget(xmaxText);
    xcoordinateLayout->addWidget(xmax,Qt::AlignLeft);
    ycoordinateLayout->addWidget(ymaxText);
    ycoordinateLayout->addWidget(ymax,Qt::AlignLeft);
    middleCoordinateLayout->addWidget(xzText);
    middleCoordinateLayout->addWidget(zx,Qt::AlignLeft);
    middleCoordinateLayout->addWidget(yzText);
    middleCoordinateLayout->addWidget(zy,Qt::AlignLeft);
    ZAP_middleCoordinateLayout->addWidget(ZAP_xmText);
    ZAP_middleCoordinateLayout->addWidget(ZAP_xm,Qt::AlignLeft);
    ZAP_middleCoordinateLayout->addWidget(ZAP_ymText);
    ZAP_middleCoordinateLayout->addWidget(ZAP_ym,Qt::AlignLeft);
    //默认关闭的按钮
    pauseFolderBtn->setEnabled(false);

    //按钮状态监听函数
    connect(openImageBtn,&QPushButton::clicked,this,&MainWindow::onOpenImageBtnClicked); //单图片检测
    connect(openFolderBtn,&QPushButton::clicked,this,&MainWindow::onOpenFolderBtnClicked); //文件夹检测
    connect(openCameraBtn,&QPushButton::clicked,this,&MainWindow::onOpenCameraBtnClicked); //摄像头检测
    connect(closeImageBtn,&QPushButton::clicked,this,&MainWindow::onCloseImageBtnClicked); //关闭图片
    connect(pauseFolderBtn,&QPushButton::clicked,this,&MainWindow::onPauseFolderBtnClicked); //暂停文件夹检测
    connect(otherFunctionsBtn,&QPushButton::clicked,this,&MainWindow::onOtherFunctionsBtnClicked); //切换到其他功能界面
/************************ 界面UI布局 END ************************/


/************************ 子线程/串口管理 BEGIN ************************/
    // -------------------------运行到这里333333----------------------
    //串口界面设置为独立窗口
    s=new SerialWindow(this); //父对象设为MainWindow，只会创建一次，并且跟随主窗口一同销毁
    s->setWindowFlags(Qt::Window); //关键：设置窗口标志为 Qt::Window，使其成为独立窗口
    s->setObjectName("SerialUI");

    s2=new other_functions(this);
    s2->setWindowFlags(Qt::Window);
    s2->setObjectName("FunctionUI");



    //注册非Qt类型
    qRegisterMetaType<DetectionResults>("DetectionResults");

    //实例化子线程任务对象
    imgDetectionWorker = new ImgDetectionWorker(this);
    camThread= new CamThread(this);

    //串口方面
    daemonthread = new DaemonThread(nullptr); //需要移动到其他线程的对象,不要给它设置父对象
    daemonthread->moveToThread(&workerThread);//注意程序结束前先让workerThread这个线程停下来
    workerThread.start(); //后台线程一直开启
    // -------------------------运行到这里44444----------------------


    //子线程连接建立
    connect(imgDetectionWorker,SIGNAL(resultReady(DetectionResults)),this, SLOT(handleResults(DetectionResults))); //图片/文件夹子线程信号
    connect(imgDetectionWorker,SIGNAL(resultLast(bool)),this,SLOT(handleLastResults(bool))); //图片/文件夹线程最后一次信号
    connect(camThread,SIGNAL(updateUI(QImage,DetectionResults)),this,SLOT(handleResults(QImage,DetectionResults))); //摄像头子线程信号
    connect(s2->videoOut,SIGNAL(updateUI(QImage,DetectionResults)),this,SLOT(handleResults(QImage,DetectionResults))); //测试
    connect(imgDetectionWorker,&QThread::finished,this,&MainWindow::isImgDetectionFinished);
    connect(s2, &other_functions::requestShowSerialUI, this, &MainWindow::showSerialFullScreen); //其他功能界面跳转串口界面   
    connect(s, &SerialWindow::goBackToOtherFunctionUI,this,&MainWindow::showOtherFunctionUIFullScreen); //串口界面跳转其他功能界面
    connect(s2, &other_functions::update_rtsp,camThread,&CamThread::update_rtsp);
    connect(s2, &other_functions::send_data_source,s,&SerialWindow::sendHexData);
    connect(s2, &other_functions::danzhou_init_send,daemonthread,&DaemonThread::danzhou_init_receive);
    connect(s2, &other_functions::test_0,daemonthread,&DaemonThread::danzhou_test_0);
    connect(s2, &other_functions::test_1,daemonthread,&DaemonThread::danzhou_test_1);
    connect(s2, &other_functions::test_2,daemonthread,&DaemonThread::danzhou_test_2);
    connect(s2, &other_functions::test_3,daemonthread,&DaemonThread::danzhou_test_3);
    connect(s2, &other_functions::test_4,daemonthread,&DaemonThread::danzhou_test_4);
    connect(s2, &other_functions::Factory_reset_send,daemonthread,&DaemonThread::danzhou_Factory_reset);
    connect(camThread,&CamThread::map_and_move_send,daemonthread,&DaemonThread::Map_and_Move);
    connect(s2, &other_functions::goBackToMainWindow,this,[=](bool status){
        showMainWindowFullScreen();
        if(status == true) {
            this->pauseFolderBtn->setEnabled(true);
            this->openImageBtn->setEnabled(false);
            this->openFolderBtn->setEnabled(false);
            this->openCameraBtn->setEnabled(false);
            this->closeImageBtn->setEnabled(false);
        } else {
            openFolderBtn->setEnabled(true);
            pauseFolderBtn->setEnabled(false);
            this->openFolderBtn->setEnabled(true);
            this->openCameraBtn->setEnabled(true);
            this->closeImageBtn->setEnabled(true);
            pauseFolderBtn->setText("暂停");
            showFloatingMessage("性能检测结束",3000);
            ispause = false;
        }
    });
    // -------------------------运行到这里5555555----------------------

/************************ 子线程/串口管理 END ************************/
}

//关闭qt程序时生效
MainWindow::~MainWindow() {
    /* 进程退出，注意本例 run()方法没写循环，此方法需要有循环才生效 */
    imgDetectionWorker->quit();
         /* 阻塞等待 2000ms 检查一次进程是否已经退出 */
         if (imgDetectionWorker->wait(2000)) {
        delete imgDetectionWorker;
        imgDetectionWorker = nullptr; // <--- 重要：必须置空！，否则widget销毁会在delete一次imgDetectionWorker
         qDebug()<<"线程已经结束！";
     }

     // 销毁摄像头工作对象
     if (camThread) {
         camThread->stop();
         QThreadPool::globalInstance()->waitForDone(2000);
         delete camThread;
     }

    workerThread.quit();//使线程停下来，因为是栈上定义的对象，随着主程序销毁而销毁，但必须先使程序停下来
    delete daemonthread;

     // 线程对象会在此时随主窗口一起析构（因为是普通对象类型）
     // 如果是指针对象类型，实例化的时候 workThread = new QThread(this);就能随着主窗口一起析构了
}


/************************ 图片/文件夹、摄像头检测按钮槽函数 BEGIN ************************/
//A.CPP通过方法改变路径，让B.cpp使用的方法就是在头文件中声明这个变量，然后定义写在B.cpp的全局

//打开图片按钮槽函数
void MainWindow::onOpenImageBtnClicked()
{
    // 指定初始目录
    QString initialDir = "/M/qtdemo/model/images";
    //转换QString为const char*的方法
    QString imgpath=QFileDialog::getOpenFileName(this,"选择图片",initialDir,"图片文件(*.png *.jpg *.bmp)");//返回选择的文件的完整路径
    if(imgpath.isNull())
    {
        QMessageBox::warning(this, "警告", "未选择图片！");
        return ;//如果在文件夹中，没选择打开按钮
    }
    imgDetectionWorker->singleimgpath=imgpath;//singleimagpath在singleimgpath对象里定义的是公有的，所以这里可以直接把imgpath路径传过去！
  if (!imgDetectionWorker->isRunning())
      imgDetectionWorker->start();//如果打开图片的线程没运行，则让他启动。start()函数可以启动imgDetectionWorker线程类里的run()方法。
  openFolderBtn->setEnabled(false);
  openCameraBtn->setEnabled(false);
  closeImageBtn->setEnabled(false); //close一定要等待图片加载出来再关闭，否则没用
  isimageopen=true;
}

//关闭图片按钮槽函数
void MainWindow::onCloseImageBtnClicked()
{
    QPixmap pixmap(":icons/template.jpg");
    if (!pixmap.isNull()) {
        imageLabel->setPixmap(pixmap.scaled(1200, 700, Qt::IgnoreAspectRatio)); //直接设置缩放大小
        imageLabel->setAlignment(Qt::AlignLeft);
        imageLabel->setAlignment(Qt::AlignTop);
        // 图片顶部显示 #如果设置AlignCenter的话，图片距离顶端可能会有间距
    } else {
        imageLabel->setText("默认图片加载失败");
        imageLabel->setAlignment(Qt::AlignCenter); //文字居中显示
    }
    openFolderBtn->setEnabled(true);
    openCameraBtn->setEnabled(true);
    closeImageBtn->setEnabled(true);
    isimageopen=false;
}

//打开摄像头按钮槽函数
void MainWindow::onOpenCameraBtnClicked()
{
    if(!isCameraOpen)//isCameraOpen默认为false，这里直接进入if
    {
        QThreadPool::globalInstance()->setMaxThreadCount(3);//设置3个线程（摄像头帧数有限制的话没用）
        // 检查线程是否为nullptr，避免重复启动
        QThreadPool::globalInstance()->start(camThread);//线程启动，执行camThread的run方法
        showFloatingMessage("线程正在启动",1000);
        openCameraBtn->setText("关闭检测");
        openImageBtn->setEnabled(false);
        openFolderBtn->setEnabled(false);
        isCameraOpen=true;

    }else{
        camThread->stop();//设置m_stop标志位为true
        // 等待线程池中的所有任务完成（添加waitForDone）
        QThreadPool::globalInstance()->waitForDone(2000); // 2000ms超时
        openCameraBtn->setText("摄像头");
        openImageBtn->setEnabled(true);
        openFolderBtn->setEnabled(true);
        isCameraOpen=false;
        showImageLabel();
    }
}

//打开/关闭文件夹按钮槽函数
void MainWindow::onOpenFolderBtnClicked()
{
    if(!isfolderopen)
    {
    // 指定初始目录
    QString initialDir = "/M/qtdemo/model";
    // 弹出文件夹选择对话框
    folderPath = QFileDialog::getExistingDirectory(this, "选择文件夹",initialDir, QFileDialog::ShowDirsOnly);
    if (folderPath.isEmpty()) {
        QMessageBox::warning(this, "警告", "未选择文件夹");
        return;
    }
    // 获取文件夹中的所有图片文件
    QDir folderDir(folderPath);
    QStringList filters = {"*.png", "*.jpg", "*.bmp"};
    QStringList imageFiles = folderDir.entryList(filters, QDir::Files); // 获取符合条件的文件列表
    if (imageFiles.isEmpty()) {
        QMessageBox::warning(this, "警告", "文件夹中没有图片文件");
        return;
    }
    isfolderopen=true;
    imgDetectionWorker->filelist=imageFiles;
    imgDetectionWorker->folderpath=folderPath;
    if (!imgDetectionWorker->isRunning())
        imgDetectionWorker->start(); //启动检测线程的run(),跟上面打开但个图片的任务是一样的，各自通过imgDetectionWorker指针对象进入
    openFolderBtn->setText("关闭检测");
    pauseFolderBtn->setEnabled(true);
    openImageBtn->setEnabled(false);
    openCameraBtn->setEnabled(false);
    closeImageBtn->setEnabled(false);
    image_mkdir_test = true;

    } else {
        isfolderopen=false;
        imgDetectionWorker->stop();
        showFloatingMessage("正在关闭检测",3000);
        isCloseHandle=false;
        image_mkdir_test = false;
    }

}

//暂停文件夹或性能测试按钮槽函数
void MainWindow::onPauseFolderBtnClicked()
{
    if(image_mkdir_test) {
        if(!ispause)
        {
         imgDetectionWorker->pause();
         pauseFolderBtn->setText("继续");
         openFolderBtn->setEnabled(false);
         showFloatingMessage("正在暂停中...",3000);
         ispause=true;
        }else{
            imgDetectionWorker->next();
            openFolderBtn->setEnabled(true);
            pauseFolderBtn->setText("暂停");
            showFloatingMessage("检测继续",3000);
            ispause=false;
        }
    } else {
        if(!ispause)
        {
            //不再执行下面的语句
            //性能测试停止，发送停止信号
            emit stop();
            pauseFolderBtn->setText("继续");
            openFolderBtn->setEnabled(false);
            showFloatingMessage("性能检测正在暂停中...",3000);
            ispause=true;
        }else{
            //再次点击一次性能测试
            emit reStart();
            openFolderBtn->setEnabled(true);
            pauseFolderBtn->setText("暂停");
            showFloatingMessage("性能检测继续",3000);
            ispause=false;
        }
    }
}
/************************ 图片/文件夹、摄像头检测按钮槽函数 END ************************/


/************************ 图片/文件夹、摄像头检测信号槽函数 BEGIN ************************/
void MainWindow::handleResults(DetectionResults results)
    {
      if (!results.img.isNull()) imageLabel->setPixmap(QPixmap::fromImage(results.img).scaled(1200, 700, Qt::IgnoreAspectRatio));

      //判断正常结束
      if(isLastHandle_m)
      {
          showFloatingMessage("检测已全部完成",200);
          isLastHandle_m=false;
      }

      //判断暂停
      if(ispause)showFloatingMessage("检测已暂停",3000);

      //判断手动结束
      if(isCloseHandle)
      {
          showFloatingMessage("检测已关闭",3000);
          QPixmap pixmap(":icons/template.jpg");
          if (!pixmap.isNull()) {
              imageLabel->setPixmap(pixmap.scaled(1200, 700, Qt::IgnoreAspectRatio)); // 直接设置缩放大小
              imageLabel->setAlignment(Qt::AlignLeft);
              imageLabel->setAlignment(Qt::AlignTop);
              // 图片顶部显示 #如果设置AlignCenter的话，图片距离顶端可能会有间距
          } else {
              imageLabel->setText("默认图片加载失败");
              imageLabel->setAlignment(Qt::AlignCenter); // 文字居中显示
          }
          isCloseHandle=false;//恢复标志为
      }

      //更新总目标数量
      totalTargetsCount->setText(QString::number(results.targetsCount));

      //更新下拉选择框
      detectionBoxComboBox->clear();
      detectionBoxComboBox->addItems(results.items);  // 安全更新 UI

      //更新坐标信息
      if (!results.detectionBoxes.isEmpty()) {
          QRect box = results.detectionBoxes.first(); // 获取第一个检测框

          //更新置信度
          double value=results.BOX.first().toDouble();
          QString formattedValue = QString::number(value, 'f', 2);
          Box->setText(formattedValue+"%");

          // 假设已有四个QLabel指针
          xmin->setText(QString::number(box.left()));     // xmin
          xmax->setText(QString::number(box.right()));    // xmax
          ymin->setText(QString::number(box.top()));      // ymin
          ymax->setText(QString::number(box.bottom()));   // ymax

          //发送数据，提取坐标值并转换为 int32_t
          // int32_t xmin_ = static_cast<int32_t>(box.left());
          // int32_t xmax_ = static_cast<int32_t>(box.right());
          // int32_t ymin_ = static_cast<int32_t>(box.top());
          // int32_t ymax_ = static_cast<int32_t>(box.bottom());

          //if(s->isSerialOpen==true)s->sendCoordinates(xmin_,xmax_,ymin_,ymax_);
      }

      // 连接前确保断开旧连接
      if (m_comboConnection) disconnect(m_comboConnection);

      //连接函数，其中槽函数是lambda形式，不需要声明
      m_comboConnection =connect(detectionBoxComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
             this, [this,results](int index) {   //显示捕获results(因为是局部变量，所以要捕获)
                 // 检查索引是否有效
                 if (index >= 0 && index < results.detectionBoxes.size()) {
                     // 获取当前选中的矩形框
                     QRect box = results.detectionBoxes[index];
                     //将QStringList格式化为两位小数并转换为QLabel
                     double value = results.BOX.at(index).toDouble();
                     QString formattedValue = QString::number(value, 'f', 2);
                     Box->setText(formattedValue+"%");
                     // 更新四个 QLabel 显示坐标
                     xmin->setText(QString::number(box.left()));     // xmin
                     xmax->setText(QString::number(box.right()));    // xmax
                     ymin->setText(QString::number(box.top()));      // ymin
                     ymax->setText(QString::number(box.bottom()));   // ymax

                     //发送数据给串口，提取坐标值并转换为 int32_t
                     // int32_t xmin_ = static_cast<int32_t>(box.left());
                     // int32_t xmax_ = static_cast<int32_t>(box.right());
                     // int32_t ymin_ = static_cast<int32_t>(box.top());
                     // int32_t ymax_ = static_cast<int32_t>(box.bottom());

                     //if(s->isSerialOpen==true)s->sendCoordinates(xmin_,xmax_,ymin_,ymax_);
                 }});

}

//接受并保存子线程最后一次发送的信号
void MainWindow::handleLastResults(bool isLastHandle){
    isLastHandle_m=isLastHandle;    //保存在全部变量中
    return;
}
/************************ 图片/文件夹、摄像头检测信号槽函数 END ************************/


/***************************摄像头信号槽函数 BEGIN ****************************/
void MainWindow::handleResults(QImage img,DetectionResults results)
{
    imageLabel->setPixmap(QPixmap::fromImage(img).scaled(1200, 700, Qt::IgnoreAspectRatio));
    //更新总目标数量
    totalTargetsCount->setText(QString::number(results.targetsCount));
    //更新下拉选择框
    detectionBoxComboBox->clear();
    detectionBoxComboBox->addItems(results.items);  // 安全更新 UI
    //更新坐标信息
    if (!results.detectionBoxes.isEmpty()) {
        QRect box = results.detectionBoxes.first(); // 获取第一个检测框
        //更新置信度
        double value=results.BOX.first().toDouble();
        QString formattedValue = QString::number(value, 'f', 2);
        Box->setText(formattedValue+"%");
        // 假设已有四个QLabel指针
        xmin->setText(QString::number(box.left()));     // xmin
        xmax->setText(QString::number(box.right()));    // xmax
        ymin->setText(QString::number(box.top()));      // ymin
        ymax->setText(QString::number(box.bottom()));   // ymax

        //发送数据给串口，提取坐标值并转换为 int32_t
        // int32_t xmin_ = static_cast<int32_t>(box.left());
        // int32_t xmax_ = static_cast<int32_t>(box.right());
        // int32_t ymin_ = static_cast<int32_t>(box.top());
        // int32_t ymax_ = static_cast<int32_t>(box.bottom());

        //if(s->isSerialOpen==true)s->sendCoordinates(xmin_,xmax_,ymin_,ymax_);

        //中心点坐标
        x=(box.left()+box.right())/2;
        y=(box.top()+box.bottom())/2;
    }
    // 连接前确保断开旧连接
    if (m_comboConnection) disconnect(m_comboConnection);

    //槽函数的lambda形式，不需要声明
    // 建立新连接
    m_comboConnection =connect(detectionBoxComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged),
        this, [this,results](int index) {   //显示捕获results(因为是局部变量，所以要捕获)
        // 检查索引是否有效
        if (index >= 0 && index < results.detectionBoxes.size()) {
        // 获取当前选中的矩形框
        QRect box = results.detectionBoxes[index];
        //将QStringList格式化为两位小数并转换为QLabel
        double value = results.BOX.at(index).toDouble();
        QString formattedValue = QString::number(value, 'f', 2);
        Box->setText(formattedValue+"%");

        //Map_and_Send(); //改成后台线程处理

        // 更新四个 QLabel 显示坐标
        xmin->setText(QString::number(box.left()));     // xmin
        xmax->setText(QString::number(box.right()));    // xmax
        ymin->setText(QString::number(box.top()));      // ymin
        ymax->setText(QString::number(box.bottom()));   // ymax

        zx->setText(QString::number(x));
        zy->setText(QString::number(y));


        // QTimer::singleShot(3000, this, [this]() {
        //     //根据y坐标计算增加的延迟时间
        //     int k=10;
        //     int addtime=y*k;
        //     QTimer::singleShot(addtime, this, [this](){
        //         duoji->left_or_right_move(x);
        //         ZAP_xm->setText(QString::number(duoji->Xs));
        //     });
        // });

        //目前串口需求只有一个，先默认一直打开不关闭
        // if(camThread->isCameraThreadFinished)
        // {
        //     //delete duoji; //正确的删除时机
        //     //delete danzhou_c;
        //     //delete rtsp_camera; //我的程序的核心功能对象直接和窗口共存亡呗，没必要频繁创建与销毁

        //     daemonthread->serialport->serialport_close(); //关闭串口
        //     qDebug()<<"串口已关闭";
        // }
    }});
}
/***************************摄像头信号槽函数 END ****************************/


/***************************子线程状态槽函数 BEGIN ****************************/
void MainWindow::isImgDetectionFinished()
{
    openImageBtn->setEnabled(true);
    openFolderBtn->setEnabled(true);
    openCameraBtn->setEnabled(true);
    closeImageBtn->setEnabled(true);
    pauseFolderBtn->setEnabled(false);
    openFolderBtn->setText("文件夹");
    isfolderopen=false; //增加容错率，事实上不写上这个一定会出问题
}

void MainWindow::showFloatingMessage(const QString& message, int timeout)
 {
     //如果存在上一次的提示信息，销毁它
     if (floatingMessageLabel) {
         floatingMessageLabel->deleteLater(); //安全销毁
     }

     //创建新的提示信息标签
     floatingMessageLabel = new QLabel(this);
     floatingMessageLabel->setStyleSheet("background-color: rgba(0, 0, 0, 150); color: white; padding: 10px; border-radius: 5px;");
     floatingMessageLabel->setAlignment(Qt::AlignCenter);
     floatingMessageLabel->setFixedSize(300, 60); //设置固定大小

     //设置提示信息内容
     floatingMessageLabel->setText(message);

     //计算提示框的位置（居中显示）
     int x = (width() - floatingMessageLabel->width()) / 2;
     int y = height() - 400; // 距离底部 450 像素
     floatingMessageLabel->move(x, y);

     //显示提示框
     floatingMessageLabel->show();

     //使用 QTimer 设置定时器，在指定时间后销毁提示框
     QTimer::singleShot(timeout, this, [this]() {//第一个this代表，如果在指定时间内没有取消，就运行下面的lambda表达式，第二个this，是为下面的lambda表达式给一个this指针，让他用
         if (floatingMessageLabel) {             //singleShot这是一个封装在QTimer的函数，他代表只会在倒计时即ms结束后执行一次下面的函数。
             //淡出动画
             QPropertyAnimation *animation = new QPropertyAnimation(floatingMessageLabel, "windowOpacity");
             animation->setDuration(1000); //动画持续时间
             animation->setStartValue(1.0); //初始透明度
             animation->setEndValue(0.0); //最终透明度
             animation->start(QAbstractAnimation::DeleteWhenStopped);
             //动画结束后销毁提示框
             connect(animation, &QPropertyAnimation::finished, floatingMessageLabel, &QLabel::deleteLater);//这对应了时间结束后销毁提示框
         }
     });
 }
/***************************子线程状态槽函数 END ****************************/


/***************************串口配置按钮槽函数 BEGIN ****************************/
// void MainWindow::onConfigSerialBtnClicked()
//     {
//         //打开串口界面
//         s->showFullScreen();
//     }
/***************************串口配置按钮槽函数 END ****************************/

void MainWindow::onOtherFunctionsBtnClicked()
{
    //打开其他功能界面
    s2->showFullScreen();
    delayMs(80); //页面切换不加延迟就会闪烁
    this->hide();
}

void MainWindow::showSerialFullScreen() {
    s->showFullScreen(); // 直接访问普通对象
    delayMs(50);
    s2->hide();
    this->hide();
}

void MainWindow::showOtherFunctionUIFullScreen() {
    s2->showFullScreen();
    delayMs(50);
    s->hide();
    this->hide();
}

void MainWindow::showMainWindowFullScreen() {
    this->showFullScreen();
    delayMs(80);
    s2->hide();
    s->hide();
}

// 辅助函数：非阻塞延迟（不卡界面）
void MainWindow::delayMs(int ms)
{
    QEventLoop loop;
    QTimer::singleShot(ms, &loop, &QEventLoop::quit);
    loop.exec();
}

void MainWindow::showImageLabel()
{
    //100ms的延迟
    QTimer::singleShot(100, this, [=]() {
        QPixmap pixmap(":icons/template.jpg");
        imageLabel->setPixmap(pixmap.scaled(1200, 700, Qt::IgnoreAspectRatio));
        showFloatingMessage("检测已关闭",3000);
    });
}
