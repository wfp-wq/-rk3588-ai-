#ifndef IMG_THREAD_H
#define IMG_THREAD_H
#include <QThread>
#include "yolov8_img/yolov8.h"
#include<QDebug>
#include<QDir>
#include<QMutex>
/*ImgDetectionWorker线程类*/
class ImgDetectionWorker;

/*新建一个ImgDetectionWorker类继承于QThread*/
class ImgDetectionWorker : public QThread
{
    /*用到信号槽即需要此宏定义*/
    Q_OBJECT
public:
    struct receiveData{
        QStringList filelist;
        QString folderpath;
    };
    receiveData receivedata;
    QStringList filelist;
    QString folderpath;
    QString singleimgpath;//在mainwindow.cpp里初始化了
    int currentImageIndex=0;
    int recorder=0;
    bool isLastHandle=false;
private:

public:
    ImgDetectionWorker(QWidget *parent=nullptr)
    {
        Q_UNUSED(parent);
    }
    void stop();
    void pause();
    void next();
    DetectionResults results;
    /*重写run方法，继承QThread的类，只有run方法是在新的线程里*/
    void run() override    //将run()函数写成for循环就能连续检测了。文件夹图片的数量
    {
        if(!filelist.isEmpty()) //filelist是从文件夹导入多张图片检测
        {
             //如果标志位为true则退出run()函数
            // 获取当前图片名称 //判断条件是<，写上=检测到最后一张以后就会崩溃,读取空内容导致的
            for(currentImageIndex=0;currentImageIndex<filelist.size();currentImageIndex++)//用循环将图片的路径一一导进去
            {
             if (m_pause) {
                // qDebug()<<"我一直在";
                 currentImageIndex=recorder; //每次重复睡眠都要设置currentImageIndex为暂停前的状态
                 QThread::msleep(100);    // 暂停时短暂休眠，避免空转 //用户的继续操作，反应在100ms内
                 continue;                // 跳过后续逻辑，直接进入下一轮循环
             }else{
                 recorder=currentImageIndex; //如果在检测中或恢复检测，同步recorder和currentImageIndex
                                            //一旦暂停检测，就没有这一句，recorder一直保持暂停前的状态
             }
             if(m_stop)break;
             QString imageName = filelist.at(currentImageIndex);
             QString imagePath = QDir(folderpath).filePath(imageName);
             results=img_main(imagePath);
             //这个信号必须写在上面
             if(currentImageIndex==filelist.size()-1)
             {
                 isLastHandle=true;
                 emit resultLast(isLastHandle);
                 isLastHandle=false;
             }

             emit resultReady(results);
            }
        }else{
        /*这里写上比较耗时的操作*/
        QString imagePath=singleimgpath; //如果选择的是但一图片，就只检测但一图片
        results=img_main(imagePath);
        /********************/
        /*发送结果准备好的信号*/
        emit resultReady(results);
        }
        m_stop=false;
        filelist.clear(); //一定要清空，否则单图片检测会继续启用文件夹检测
    }
signals:
    /*声明一个信号，译结果准确号的信号*/
    void resultReady(DetectionResults results);
    void resultLast(bool isLastHandle);
private:
    receiveData receiver(const QStringList &filelist,const QString &folderPath);
    bool m_stop;    // 线程停止标志
    bool m_pause;   //线程暂停标志
    QMutex m_mutex; // 互斥锁
};

#endif // IMG_THREAD_H
