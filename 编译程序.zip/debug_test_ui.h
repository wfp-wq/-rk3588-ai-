#ifndef DEBUG_TEST_UI_H
#define DEBUG_TEST_UI_H

#include <QWidget>
#include "yolov8_img/yolov8.h"
#include "videoReader.h"
#include "videoOut.h"
#include "threadPool.h"
#include "Peripherals/iic/accelApp.h"
#include <QHostAddress>
#include <QMessageBox>
#include <QToolTip>
#include <QProcess>
#include <QEventLoop>
#include <QTimer>
#include "animation/wait_animation.h"

class MainWindow;  // 前向声明

namespace Ui {
class other_functions;
}

//QWidget是QObject的子类
class other_functions : public QWidget
{
    Q_OBJECT

public:
    explicit other_functions(QWidget *parent = nullptr);
    ~other_functions();


    Ui::other_functions *ui;

    //读视频流线程
    QThread *firstThread;
    //推流线程
    QThread *thirdThread;
    //推理任务
    VideoReader *videoReader; //读取视频流任务
    VideoOut *videoOut;//推流任务
    QThreadPool *m_threadPool;
    const int maxFrameCount=9; //并行处理的最大帧的数量
    int activeThreads; //当前活跃的线程数量

    rknn_app_context_t rknn_app_ctx;
    int ret;

    //动画工具
    Wait_Animation *m_waitAnim;


    void model_init();
    void model_release();
    void delayMs(int ms);

private:
    MainWindow *mainWindow;
    bool isTestButton;

signals:
    void requestShowSerialUI();//请求显示串口界面 （使用信号槽有利于解耦，不同界面之间直接交流）
    void send(bool isRunning);
    void update_rtsp(std::string ipAddress);
    void send_data_source(QString data_source);
    void danzhou_init_send();
    void test_0();
    void test_1();
    void test_2();
    void test_3();
    void test_4();
    void goBackToMainWindow(bool status);
    void Factory_reset_send();

private slots:
    void on_thread_pool_button_clicked();//性能测试
    void on_pushButton_2_clicked(); //串口界面
    void on_pushButton_3_clicked(); //返回主界面
    void startPool(FrameData frameData);
    void wakeup();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_test_4_clicked();
    void on_test_3_clicked();
    void on_test_2_clicked();
    void on_test_1_clicked();
    void on_test_0_clicked();
    void on_danzhou_init_clicked();
    void on_SB_danzhou_clicked();
    void on_pushButton_6_clicked();
    void test_stop();      //暂停
    void test_restart();
    void test_quit();      // 完全停止
};

#endif // DEBUG_TEST_UI_H
