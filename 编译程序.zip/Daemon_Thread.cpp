#include "Daemon_Thread.h"

DaemonThread::DaemonThread(QObject *parent):QObject(parent)
{
    serialport = new SerialPort(this);
    rtsp_camera = new RTSP_Camera(this);
    wait_animation = new Wait_Animation(this);//缓冲动画显示
    isFinished=false;
}

DaemonThread::~DaemonThread()
{
    delete serialport;
    delete rtsp_camera;
    delete wait_animation;
}

void DaemonThread::Map_and_Move(int target_x)
{
    if(!isFinished){
        isFinished=true;

        //延迟不适合写在这个函数里面，延迟应该写在外面
        //serialport->delayMs(2100); //先测试y=200时多少延迟合适吧
                                     //粗略比例，不准确：y=185对应2100ms
                                     //k=11.35ms/坐标

        //判断是否超过最大距离
        int distance=(int)(target_x*0.64);
        qDebug()<<distance;
        if(distance > 580)
        {
            qDebug()<<"Warning:超过最大移动距离";
            isFinished=false;
            return;
        }

        //设置移动距离
        QString hexData = rtsp_camera->CoordinateMapDistance(target_x);//int转QString(距离转成Modbus协议的发射信号)
        serialport->sendHexData(hexData);// “01 06 00 10 00 ～ ～”，把“移动距离”这个数据写进了串口发送给电机
        serialport->delayMs(100); //100ms是稳定的
        qDebug()<<"设置移动距离";

        //启动绝对运动
        serialport->sendHexData("01 05 00 03 FF 00 7C 3A");//给电机的启动开关（线圈）发了一个“ON”的信号，启动运动，在 Modbus 协议里，FF 00 代表 “ON”（接通/置位）
        serialport->delayMs(100);
        qDebug()<<"启动绝对运动";
        qDebug()<<hexData;
        qDebug()<<"移动了";
        isFinished=false;
    }
}

//回零初始化中
//改造为回零函数（初始化函数重新写一个）
void DaemonThread::danzhou_init_receive()//初始化(包括回零)按钮
{
    /*
     * 绝对移动初始化（加速度默认）
     */
    //设置移动速度
    //看modbus图
    //01代表控制器地址为1;06代表功能码，意思是写单个寄存器;00 06代表查地址表0x0006为"速度1低";03 20代表写入的数据0x0320=3*16^2+2*16=800mm;68 E3为校验码
    serialport->sendHexData("01 06 00 06 03 20 68 E3");//80cm/s，搜索“Modbus CRC16计算器”，输入010600060320，自动生成校验码68E3
    qDebug()<<"设置移动速度"; //确实是被delayMs()的循环给阻塞住了
    serialport->delayMs(100);

    //设置加速度
    //根上面一样，代表往从站地址01的单个寄存器里面的"加速度1低"写入2000
    serialport->sendHexData("01 06 00 08 07 D0 0B A4");//200cm/s^2
    serialport->delayMs(100);

    //设置减速度
    serialport->sendHexData("01 06 00 0A 07 D0 AA 64");//200cm/s^2
    serialport->delayMs(100);

    /*
     * 手动回零
     */

    //设置回零方向
    serialport->sendHexData("01 06 00 1C 00 02 C9 CD");
    serialport->delayMs(100);

    //设置移动距离
    //serialport->sendHexData("01 06 00 10 00 00 88 0F"); //0mm
    //serialport->delayMs(100);

    //启动手动回零
    serialport->sendHexData("01 05 00 0B FF 00 FC 3A");
    serialport->delayMs(100);

    /*
     * 回零操作（加速度默认）
     */

    //设置回零方向
    // serialport->sendHexData("01 06 00 1C 00 02 C9 CD");
    // serialport->delayMs(100);

    //设置回零加速度
    //serialport->sendHexData("01 06 00 20 00 14 88 0F"); //20cm/s^2
    //serialport->delayMs(100);

    //设置回零速度为800mm/s (100mm/s 最大距离回零OK)——后面得加一个“等待回零”的圆形循环等待动画
    //serialport->sendHexData("01 06 00 1E 00 14 E9 C3"); //50cm/s
    //serialport->delayMs(100);  // 等待前一个命令发送完成

    //启动回零
    //serialport->sendHexData("01 05 00 0B FF 00 FD F8");
    //qDebug()<<"启动回零";
}

void DaemonThread::danzhou_test_0()//"0"按钮，设置速度为10mm/s
{
    serialport->sendHexData("01 06 00 06 00 0A E9 CC");
    qDebug()<<"执行0";
}

void DaemonThread::danzhou_test_1()//"1"按钮，设置加速度为200mm/s^2
{
    serialport->sendHexData("01 06 00 08 00 C8 09 9E");
    qDebug()<<"执行1";
}

//测试CRC编码（经过测试，完全OK）
void DaemonThread::danzhou_test_2()//测试CRC编码按钮
{
}

void DaemonThread::danzhou_test_3()//设置移动距离按钮
{
    serialport->sendHexData("01 06 00 10 01 90 89 F3");//设置移动距离为40cm
    qDebug()<<"执行3";
}

void DaemonThread::danzhou_test_4()//启动绝对运动按钮
{
    //设置移动速度
    serialport->sendHexData("01 06 00 06 03 20 68 E3");//80cm/s
    serialport->delayMs(100);

    //设置加速度
    serialport->sendHexData("01 06 00 08 07 D0 0B A4");//160cm/s^2
    serialport->delayMs(100);

    //设置减速度
    serialport->sendHexData("01 06 00 0A 07 D0 AA 64");//160cm/s^2
    serialport->delayMs(100);

    //设置移动距离
    serialport->sendHexData("01 06 00 10 02 24 89 74"); //移动58cm
    serialport->delayMs(100);
    //启动绝对运动
    serialport->sendHexData("01 05 00 03 FF 00 7C 3A");
    serialport->delayMs(100);
    qDebug()<<"启动绝对运动";
}

void DaemonThread::danzhou_Factory_reset()//恢复单轴控制器出场设置按钮
{
    //恢复导程出厂设置
    serialport->sendHexData("01 06 00 02 00 0A A8 0D");
    serialport->delayMs(100);
    qDebug()<<"恢复导程出厂设置";
    //恢复细分出厂设置
    serialport->sendHexData("01 06 00 04 13 88 C5 5D");
    serialport->delayMs(100);
    qDebug()<<"恢复细分出厂设置";
    //恢复速度出厂设置
    serialport->sendHexData("01 06 00 06 00 32 E8 1E");
    serialport->delayMs(100);
    qDebug()<<"恢复速度出厂设置";
    //恢复加速度出厂设置
    serialport->sendHexData("01 06 00 08 00 C8 09 9E");
    serialport->delayMs(100);
    qDebug()<<"恢复加速度出厂设置";
    //恢复减速度出厂设置
    serialport->sendHexData("01 06 00 0A 00 C8 A8 5E");
    serialport->delayMs(100);
    qDebug()<<"恢复减速度出厂设置";
    //恢复停止方式出厂设置
    serialport->sendHexData("01 06 00 0E 00 01 29 C9");
    serialport->delayMs(100);
    qDebug()<<"恢复停止方式出厂设置";
    //恢复移动距离出厂设置
    serialport->sendHexData("01 06 00 10 00 64 89 E4");
    serialport->delayMs(100);
    qDebug()<<"恢复移动距离出厂设置";
    //恢复从机地址出厂设置
    serialport->sendHexData("01 06 00 18 00 01 C8 0D");
    serialport->delayMs(100);
    qDebug()<<"恢复从机地址出厂设置";
    //恢复485波特率出厂设置
    serialport->sendHexData("01 06 00 1A 00 06 28 0F");
    serialport->delayMs(100);
    qDebug()<<"恢复485波特率出厂设置";
    //恢复回零方向出厂设置
    serialport->sendHexData("01 06 00 0C 00 01 88 09");
    serialport->delayMs(100);
    qDebug()<<"恢复回零方向出厂设置";
    //恢复回零速度出厂设置
    serialport->sendHexData("01 06 00 1E 00 0A 69 CB");
    serialport->delayMs(100);
    qDebug()<<"恢复回零速度出厂设置";
    //恢复回零加速度出厂设置
    serialport->sendHexData("01 06 00 20 01 2C 88 4D");
    serialport->delayMs(100);
    qDebug()<<"恢复回零加速度出厂设置";
    //恢复回零脱落距离出厂设置
    serialport->sendHexData("01 06 00 22 00 05 E9 C3");
    serialport->delayMs(100);
    qDebug()<<"恢复回零脱落距离出厂设置";
    //恢复回零超时时间出厂设置
    serialport->sendHexData("01 06 00 24 27 10 D3FD");
    serialport->delayMs(100);
    qDebug()<<"恢复回零超时时间出厂设置";
    //恢复速度2出厂设置
    serialport->sendHexData("01 06 00 28 00 32 88 17");
    serialport->delayMs(100);
    qDebug()<<"恢复速度2出厂设置";
    //恢复软件负限位出厂设置
    serialport->sendHexData("01 06 00 2A 00 C8 A9 94");
    serialport->delayMs(100);
    qDebug()<<"恢复软件负限位出厂设置";
    //恢复软件正限位出厂设置
    serialport->sendHexData("01 06 00 2C 00 C8 49 95");
    serialport->delayMs(100);
    qDebug()<<"恢复软件正限位出厂设置";
    //恢复输入口0功能出厂设置
    serialport->sendHexData("01 06 00 30 00 01 48 05");
    serialport->delayMs(100);
    qDebug()<<"恢复输入口0功能出厂设置";
    //恢复输入口1功能出厂设置
    serialport->sendHexData("01 06 00 32 00 02 A9 C4");
    serialport->delayMs(100);
    qDebug()<<"恢复输入口1功能出厂设置";
    //恢复输入口2功能出厂设置
    serialport->sendHexData("01 05 00 34 00 09 4C 02");
    serialport->delayMs(100);

    qDebug()<<"恢复输入口2功能出厂设置";
    qDebug()<<"全部功能恢复出厂设置";
}
