#ifndef VIDEOOUT_H
#define VIDEOOUT_H

#include "Mcommon.h"

class VideoOut:public QObject{
  Q_OBJECT
public:
  explicit VideoOut(QObject *parent=nullptr);

signals:
   void OutOK();
    void continue_firstThread();
    void updateUI(QImage img,DetectionResults results); // 用于更新UI的信号

private:
   QVector<FrameData> m_frameCache1;  // 帧缓存容器
   QVector<FrameData> m_frameCache2;
   qint64  lastTime;
   bool isRunning;
   qint64 currentTime;
   double fps;
   int frameCount;
   QMutex mutex;
   int frame_count;
   int record_frame_number;

public slots:
   void Out(FrameData frameData,DetectionResults results);
   void frame_receive(FrameData frameData);
   void sortFrames();
};


#endif // VIDEOOUT_H
