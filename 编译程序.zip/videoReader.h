#ifndef VIDEOREADER_H
#define VIDEOREADER_H

#include "Mcommon.h"
#include "Mpp/mpprtspdecoder.h"
#include <atomic>
#include <QMutex>
#include <QWaitCondition>


class VideoReader:public QObject{
    Q_OBJECT
public:
    FrameData frameData;
    QWaitCondition readwait;
    explicit VideoReader(QObject *parent=nullptr); //构造函数
    void pause();      // 暂停解码
    void resume();     // 恢复解码
    void stop();       // 完全停止（析构时调用）
    //析构暂时默认

signals:
    void send(FrameData frameData); //发送读取的帧数据 不能用const，因为传递过去的帧数据要进行修改

public slots:
    void Read(bool isRunning);
private:
    QElapsedTimer timer;
    bool m_isRunning;
    QMutex mutex;
    MppRtspDecoder* mppdec;
    std::atomic<bool> m_running{true};   // 线程是否运行（永不改为false，除非析构）
    std::atomic<bool> m_paused{false};   // 是否暂停解码
    QMutex m_mutex;          // 互斥锁
    QWaitCondition m_waitCond;  // 等待条件
    void delayUs(int us);
};

#endif // VIDEOREADER_H
