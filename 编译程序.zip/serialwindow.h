#ifndef SERIALWINDOW_H
#define SERIALWINDOW_H

#include <QMainWindow>
#include <QSerialPort>  //串口类
#include <QMessageBox>
#include <QFileDialog>
#include <QSerialPortInfo>  //串口信息类
#include <QStandardPaths>
#include <QWidget>
#include <QTimer>
#include <QDebug>
#include <QFile>
#include <QtEndian>  // 包含 Qt 字节序转换函数的头文件
#pragma once

namespace Ui {
class SerialWindow;
}

// 1. 定义数据包结构
#pragma pack(push, 1)  // 禁止结构体对齐（确保紧凑存储）
struct CoordinatePacket {
    uint8_t header[2] = {0xAA, 0x55};  // 起始符
    int32_t xmin;
    int32_t xmax;
    int32_t ymin;
    int32_t ymax;
    uint8_t checksum;                  // 校验和
};
#pragma pack(pop)

class SerialWindow : public QWidget
{
    Q_OBJECT

public:
    explicit SerialWindow(QWidget *parent = nullptr);
    ~SerialWindow();

    //标志位
    bool isSerialOpen;  //判断是否启用串口

    //发送坐标数据公共接口
    void sendCoordinates(int32_t xmin, int32_t xmax, int32_t ymin, int32_t ymax);

    QSerialPort *serialPort;

signals:
    void goBackToOtherFunctionUI();

public slots:
    void readData();

    void readCoordinatesData();

    void on_pushButton_clicked(bool checked);

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void sendHexData(QString dataStr);

    void delayMs(int ms);

    void displayHex();

    void onReadyRead();

    //void sendHexByte(QByteArray hexByte);


private:
    QByteArray m_receiveBuffer;  // 接收缓冲区
    Ui::SerialWindow *ui;

    QTimer timer;
};

#endif // SERIALWINDOW_H
