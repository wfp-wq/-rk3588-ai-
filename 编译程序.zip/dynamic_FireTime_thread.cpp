#include "dynamic_FireTime_thread.h"

SH3001_ACC::SH3001_ACC()
{

}

void SH3001_ACC::stop_Acc()
{
    g_stop_flag=1; //全局变量可以直接用
}

void SH3001_ACC::ACC(){
    sh3001.sh3001_Acc();
}
