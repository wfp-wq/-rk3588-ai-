#ifndef THREADPOOL_H
#define THREADPOOL_H

#include "Mcommon.h"
#include <QtConcurrent>
#include <QFuture>

// 前向声明或定义绿色检测结果结构体
struct GreenResult {
    cv::Rect best_weed;
    double max_area;
    int weed_count;
    std::vector<cv::Rect> all_weeds;
    cv::Mat green_mask;
};

class Inference:public QObject,public QRunnable{
    Q_OBJECT
public:
    FrameData frameData;
    explicit Inference(FrameData frameData,rknn_app_context_t rknn_app_ctx,int ret);

    void run() override;

signals:
    void send(FrameData frameData,DetectionResults results);

private:
    // 绿色检测函数声明
    GreenResult doGreenDetect(cv::Mat frame);

private:
    bool m_stop;    // 线程停止标志
    QMutex m_mutex; // 互斥锁
    QElapsedTimer timer;
    //推理资源
    rknn_app_context_t rknn_app_ctx;
    int ret;
    int target_x,target_y;
    bool isRunning;
    // ========== 添加类成员变量 ==========
    cv::Scalar lower_green;   // 绿色下限
    cv::Scalar upper_green;   // 绿色上限
    cv::Mat hsv;              // 复用 HSV 图像
    cv::Mat green_mask;       // 复用绿色掩码

};

#endif // THREADPOOL_H
