#include "videoReader.h"

VideoReader::VideoReader(QObject *parent): QObject(parent)
{
    m_running = true;
    m_paused = false;
}

void VideoReader::pause()
{
    m_paused = true;
    qDebug() << "解码线程已暂停";
}

void VideoReader::resume()
{
    m_paused = false;
    m_waitCond.wakeAll();  // 唤醒等待的线程
    qDebug() << "解码线程已恢复";
}

void VideoReader::stop()
{
    m_running = false;
    m_paused = false;
    m_waitCond.wakeAll();
}


void VideoReader::Read(bool isRunning)
{
    qDebug()<<"一线程正在工作中...";

    if(!isRunning)
    {
        return;
    }

    std::string rtsp = "rtsp://admin:S1234567890@192.168.1.2:554/1/1";
    qDebug()<<"开始解码";
    mppdec = new MppRtspDecoder(rtsp);
    if (mppdec->init() != 0) {
        qDebug() << "[解码线程] MPP初始化失败";
        return;
    }
    qDebug() << "[解码线程] MPP初始化成功";

    cv::Mat src_frame;
    src_frame.create(cv::Size(1280, 720), CV_8UC3);

    timer.start();

    int current_frame = 0;
    //不要在生产者线程进行任何多余的耗时处理，有可能导致推理速度大于发送速度，这样线程池设计就没有意义了，单线程都能解决
    while(m_running){
        // 检查是否暂停
        if (m_paused) {
            QMutexLocker locker(&m_mutex);
            m_waitCond.wait(&m_mutex);  // 当前线程（firstThread）在这里暂停
            continue;
        }
        /*RTSP视频流检测*/
        int ret = mppdec->decode_simple(src_frame);
        if (ret < 0 || src_frame.empty()) {
            std::cout << "有视频流未读取" << std::endl;
            continue;
        }

        current_frame++;
        if(current_frame >= 1000)
        {
            current_frame=0;
        }

        // ========== 关键修改：使用 shared_ptr ==========
        // 只拷贝一次，创建共享指针
        auto mat_ptr = std::make_shared<cv::Mat>(src_frame.clone());

        frameData.frame = mat_ptr;                      // 存指针
        frameData.current_frame = current_frame; //读取当前帧序号
        frameData.sendTime=timer.restart(); //发送时间

        emit send(frameData);

        // 检查是否为最后一帧（某些视频可能提前结束）
        // if (frameData.current_frame == frame_count) {
        //     cap.release();
        //     break;
        // }
    }
    qDebug() << "[解码线程] 开始清理 MPP 资源";
    if (mppdec) {
        delete mppdec;      // 再删除对象
        mppdec = nullptr;
    }
    qDebug() << "[解码线程] MPP 资源已清理";

    qDebug() << "[解码线程] 结束";
}

void VideoReader::delayUs(int us)
{
    if (us == 0) return;

    QElapsedTimer timer;
    timer.start();

    // 循环等待直到指定的微秒数过去
    while (timer.nsecsElapsed() / 1000 < us)
    {

    }

}


