#include "serialwindow.h"
#include "ui_serialwindow.h"
#include<QMessageBox>

SerialWindow::SerialWindow(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::SerialWindow),isSerialOpen(false)
{
    ui->setupUi(this);

    serialPort = new QSerialPort(this);

    //扫描本机的串口，并添加到下拉框里
    foreach(const QSerialPortInfo &info,QSerialPortInfo::availablePorts()){
        ui->comboBox->addItem(info.portName());
    }

    //读取数据
    //connect(serialPort,SIGNAL(readyRead()),this,SLOT(readData()));
    //读取坐标数据
    //connect(serialPort,SIGNAL(readyRead()),this,SLOT(readCoordinatesData()));
    //connect(serialPort,SIGNAL(readyRead()),this,SLOT(displayHex()));
    connect(serialPort,SIGNAL(readyRead()),this,SLOT(onReadyRead()));//运用"中断"的机制，缓冲区有数据传来就会调用onReadyRead()读取槽函数

    //on_pushButton_clicked(true); //串口默认打开
}

SerialWindow::~SerialWindow()
{
    delete ui;
}

void SerialWindow::readData()
{
    //接受数据
    ui->textBrowser->insertPlainText(serialPort->readAll());
}

//接受坐标信息
void SerialWindow::readCoordinatesData() {
    // 1. 读取原始数据并存入缓冲区
    m_receiveBuffer.append(serialPort->readAll());

    // 2. 检查缓冲区是否足够解析一个完整数据包
    while (m_receiveBuffer.size() >= sizeof(CoordinatePacket)) {
        // 查找起始符 "AA 55"
        int startPos = m_receiveBuffer.indexOf("\xAA\x55");
        if (startPos == -1) {
            m_receiveBuffer.clear();  // 未找到起始符，清空缓冲区
            return;
        }

        // 移除起始符前的无效数据
        if (startPos > 0) {
            m_receiveBuffer = m_receiveBuffer.mid(startPos);
        }

        // 检查剩余数据长度是否足够
        if (m_receiveBuffer.size() < sizeof(CoordinatePacket)) {
            return;
        }

        // 3. 提取完整数据包
        CoordinatePacket packet;
        memcpy(&packet, m_receiveBuffer.constData(), sizeof(CoordinatePacket));

        // 4. 校验数据包
        if (packet.header[0] != 0xAA || packet.header[1] != 0x55) {
            m_receiveBuffer.remove(0, 2);  // 跳过错误的起始符
            continue;
        }

        // // 计算校验和
        // uint8_t calcChecksum = 0;
        // const uint8_t *data = reinterpret_cast<const uint8_t*>(&packet) + 2;  // 跳过header
        // for (size_t i = 0; i < sizeof(packet) - 3; ++i) {
        //     calcChecksum ^= data[i];
        // }

        // if (calcChecksum != packet.checksum) {
        //     m_receiveBuffer.remove(0, sizeof(CoordinatePacket));  // 校验失败，丢弃数据包
        //     continue;
        // }

        // 5. 转换字节序并显示
        int32_t xmin = qFromBigEndian(packet.xmin);
        int32_t xmax = qFromBigEndian(packet.xmax);
        int32_t ymin = qFromBigEndian(packet.ymin);
        int32_t ymax = qFromBigEndian(packet.ymax);

        QString text = QString("xmin=%1, xmax=%2, ymin=%3, ymax=%4\n")
                           .arg(xmin).arg(xmax).arg(ymin).arg(ymax);
        ui->textBrowser->append(text);

        // 6. 移除已处理的数据
        m_receiveBuffer.remove(0, sizeof(CoordinatePacket));
    }
}

void SerialWindow::on_pushButton_clicked(bool checked)
{
    if(checked){
    //设置要打开的串口的名字
    serialPort->setPortName(ui->comboBox->currentText());

    //设置波特率
    serialPort->setBaudRate(ui->comboBox_2->currentText().toInt());

    //设置停止位
    serialPort->setStopBits(QSerialPort::StopBits(ui->comboBox_3->currentText().toInt()));

    //设置数据位
    serialPort->setDataBits(QSerialPort::DataBits(ui->comboBox_4->currentText().toInt()));

    //设置校验位
    switch(ui->comboBox_5->currentText().toInt()){
    case 0:
        serialPort->setParity(QSerialPort::NoParity);
        break;
    case 1:
        serialPort->setParity(QSerialPort::EvenParity);
        break;
    case 2:
        serialPort->setParity(QSerialPort::OddParity);
        break;
    case 3:
        serialPort->setParity(QSerialPort::SpaceParity);
        break;
    case 4:
        serialPort->setParity(QSerialPort::MarkParity);
        break;
    default:
        break;
    }

    //设置流控为无流控
    serialPort->setFlowControl(QSerialPort::NoFlowControl);

    if(!serialPort->open(QIODevice::ReadWrite)){
        QMessageBox::warning(this,"错误","串口打开失败可能被占用了");
    return;
    }
    ui->comboBox->setEnabled(false);
    ui->comboBox_2->setEnabled(false);
    ui->comboBox_3->setEnabled(false);
    ui->comboBox_4->setEnabled(false);
    ui->comboBox_5->setEnabled(false);
    ui->pushButton->setText("关闭串口");
    isSerialOpen=true;
    }else{
        //关闭串口
        serialPort->close();
        ui->comboBox->setEnabled(true);
        ui->comboBox_2->setEnabled(true);
        ui->comboBox_3->setEnabled(true);
        ui->comboBox_4->setEnabled(true);
        ui->comboBox_5->setEnabled(true);
        ui->pushButton->setText("打开串口");
        isSerialOpen=false;
    }
}


void SerialWindow::on_pushButton_2_clicked()
{
    //发送数据
    serialPort->write(ui->textEdit->toPlainText().toUtf8());

    //下面发送16进制数据的方法是有用的
    // QByteArray dataToSend = QByteArray::fromHex("01 05 00 01 FF 00 DD FA");
    // serialPort->write(dataToSend);
}


void SerialWindow::on_pushButton_3_clicked()
{
    //清空发送的数据
    ui->textEdit->clear();
    //清空接受的数据
    ui->textBrowser->clear();
}


void SerialWindow::on_pushButton_4_clicked()
{
    //返回主界面（通过隐藏串口界面的方法）
    //this->hide();
    emit goBackToOtherFunctionUI();
}


// 发送坐标数据（带协议封装）
void SerialWindow::sendCoordinates(int32_t xmin, int32_t xmax, int32_t ymin, int32_t ymax) {
    if (!serialPort || !serialPort->isOpen()) {
        QMessageBox::warning(this, "错误", "串口未打开！");
        return;
    }

    // 2. 填充数据
    CoordinatePacket packet;
    packet.xmin = qToBigEndian(xmin);  // 转换为大端字节序（网络字节序）
    packet.xmax = qToBigEndian(xmax);
    packet.ymin = qToBigEndian(ymin);
    packet.ymax = qToBigEndian(ymax);

    // // 3. 计算校验和（异或校验）
    // uint8_t *dataPtr = reinterpret_cast<uint8_t*>(&packet) + 2;  // 跳过起始符
    // size_t dataSize = sizeof(packet) - 3;  // 校验和前的数据长度（4*int32）
    // packet.checksum = 0;
    // for (size_t i = 0; i < dataSize; ++i) {
    //     packet.checksum ^= dataPtr[i];
    // }

    // 4. 发送数据
    QByteArray data(reinterpret_cast<char*>(&packet), sizeof(packet));
    serialPort->write(data);
}

/*
 * 发送16进制数据
 */
void SerialWindow::sendHexData(QString dataStr)
{
    //delayMs(30); //在这设置延迟怎么没用啊
    QByteArray hexbyte = QByteArray::fromHex(dataStr.toUtf8());
    serialPort->write(hexbyte);
}

// void SerialWindow::sendHexByte(QByteArray hexByte)
// {
//     delayMs(30);
//     //设置移动速度
//     sendHexData("01 06 00 06 01 F4 69 DC");//50cm/s
//     //设置移动距离
//     serialPort->write(hexByte);
//     delayMs(100);
//     //启动绝对运动
//     sendHexData("01 05 00 03 FF 00 7C 3A");
// }

// 辅助函数：非阻塞延迟（不卡界面）
void SerialWindow::delayMs(int ms)
{
    QEventLoop loop;
    QTimer::singleShot(ms, &loop, &QEventLoop::quit);
    loop.exec();
}

void SerialWindow::displayHex()
{
    QFont font = ui->textBrowser->font();
    font.setPointSize(31); // 设置字体大小
    ui->textBrowser->setFont(font);

    /*先读取数据*/
    auto dataStr = ui->textBrowser->toPlainText();
    /*转成十六进制*/
    auto hexData = dataStr.toLocal8Bit().toHex(' ').toUpper(); //toUpper的作用是将小写变为大写
    /*再把数据写回去*/
    ui->textBrowser->setPlainText(hexData);
}

void SerialWindow::onReadyRead()
{
    auto data = serialPort->readAll();
    //接收但不显示
    //ui->textBrowser->setPlainText(QString::fromLocal8Bit(data));
    //displayHex();
}

