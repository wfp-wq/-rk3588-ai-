#include <QThread>
#include <QDebug>
#include "Peripherals/iic/accelApp.h"

class SH3001_ACC : public QObject{
    Q_OBJECT

public slots:
    /*
     * 加速度外设
     */
    void ACC();

public:
    /*
     * 加速度外设
     */
    SH3001 sh3001;
    SH3001_ACC();
    void stop_Acc();
};
