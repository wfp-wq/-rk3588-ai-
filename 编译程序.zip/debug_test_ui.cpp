#include "debug_test_ui.h"
#include "ui_debug_test_ui.h"
#include "mainwindow.h"

const char *model_path = "./model/yolov8.rknn";

other_functions::other_functions(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::other_functions)
    , m_threadPool(QThreadPool::globalInstance())//m_threadPool 只是指向全局线程池的指针，不是自己创建的实例（不是new出来的），会自己销毁，不用delete
{
    isTestButton =false;
    ui->setupUi(this);
    ui->lineEdit->setInputMask("000.000.000.000;_");
    //ui->lineEdit->setPlaceholderText("例如：192.168.1.1");//掩码和占位符不能共存，所以setInputMask设置了格式，下面无论怎么设置默认值都不会现实

    m_waitAnim = new Wait_Animation(this);  // 纳入对象树管理
    // ✅就这一行，使用传入的 parent，不创建新的
    mainWindow = qobject_cast<MainWindow*>(parent);

    //配置线程池(9个工作线程)
    m_threadPool->setMaxThreadCount(12);
    activeThreads = QThreadPool::globalInstance()->activeThreadCount();//当前正在运行的线程数量
    qDebug() << "线程池最大线程数:" << m_threadPool->maxThreadCount();

    //创建推理线程，用的不是线程池
    firstThread = new QThread;//new表示在堆上创建，必须通过delete销毁，不会自己销毁
    thirdThread = new QThread;
    //创建任务对象
    videoReader=new VideoReader;
    videoOut=new VideoOut;
    videoReader->moveToThread(firstThread);//把videoReader放到videoReader子线程里面执行
    videoOut->moveToThread(thirdThread);


    connect(ui->thread_pool_button,&QPushButton::clicked, this,&other_functions::on_pushButton_3_clicked);//连接按钮点击事件
    connect(ui->pushButton_2, &QPushButton::clicked, this, &other_functions::on_pushButton_2_clicked);//跳转配置串口界面
    connect(ui->pushButton_3, &QPushButton::clicked, this, &other_functions::on_pushButton_3_clicked);//返回主界面
    connect(mainWindow,&MainWindow::stop,this,&other_functions::test_stop);//接受停止信号
    connect(mainWindow,&MainWindow::reStart,this,&other_functions::test_restart);//接受重启信号


    //线程池连接(一线程和主线程)
    //点击性能测试按钮，初始化模型资源和句柄，发送send信号，唤醒读取线程videoReader
    connect(this,&other_functions::send,videoReader,&VideoReader::Read,Qt::QueuedConnection);//如果用到跨线程就必须要加上QueuedConnection等待事件
    //读取线程每读取发送一个携带帧的send(frameData)信号给startPool函数，不断调用线程池里的推理线程带帧进行并行处理。
    connect(videoReader,&VideoReader::send,this,&other_functions::startPool,Qt::QueuedConnection);//设置这个阻塞队列没用，因为发送给线程池就算结束，不用等到任务结束
    connect(videoOut,&VideoOut::continue_firstThread,this,&other_functions::wakeup,Qt::QueuedConnection);
}

other_functions::~other_functions()
{
    if (videoReader) {
        videoReader->stop();  // 完全停止
    }
    // 等待线程池任务完成
    m_threadPool->waitForDone(1000); // 等待1秒让任务完成

    firstThread->quit();
    firstThread->wait();

    thirdThread->quit();
    thirdThread->wait();

    model_release();

    delete videoReader;

    delete videoOut;

    delete ui;
}

void other_functions::on_pushButton_2_clicked()
{
    // 通过A界面访问B界面并显示(适合C界面需要频繁交互B界面)
    emit requestShowSerialUI(); // 发出请求信号
}

void other_functions::on_pushButton_3_clicked()
{
    //返回主界面（通过隐藏界面的方法）
    //this->hide();
    //this->close();
    //发送给主界面的信号，为了控制ui界面的连续性，保证和摄像头测试按钮互斥稳定
    if(isTestButton == false){
    emit goBackToMainWindow(false);
    } else {
    emit goBackToMainWindow(true);
    }
}

void other_functions::on_thread_pool_button_clicked()//性能测试被点击槽函数,这里ui里面连接了槽函数就不要在构造里面写connect了，否则会重复
{
    if(!isTestButton){
        ui->thread_pool_button->setText("关闭测试");
        // 重新初始化模型
        model_init();
        // 启动线程（如果还没启动）
        if (!firstThread->isRunning()) {
            firstThread->start();
        }
        if (!thirdThread->isRunning()) {
            thirdThread->start();
        }
        // 恢复解码
        if (videoReader) {
            videoReader->resume();  // 唤醒等待的线程
        }
        emit this->send(true);
        isTestButton = true;
    } else {
        test_quit();
    }
}

void other_functions::startPool(FrameData frameData)
{
    //每次有帧传进来就创建一个QObject的task任务，然后让线程池的线程去处理这个任务，线程池的运行的线程不超过9个
    if(QThreadPool::globalInstance()->activeThreadCount()>9)
    {
        return;
    }
    qDebug()<<"执行任务前活跃线程数量："<< QThreadPool::globalInstance()->activeThreadCount();
    Inference *task=new Inference(frameData,rknn_app_ctx,ret);
    //推理结束，接收到帧处理结果和画好框的图像一起发送给显示线程videoout
    connect(task,&Inference::send,videoOut,&VideoOut::Out,Qt::QueuedConnection);
    m_threadPool->start(task);//把task任务放到线程池中
    qDebug()<<"执行任务后活跃线程数量："<< QThreadPool::globalInstance()->activeThreadCount();
}

void other_functions::wakeup()
{
    videoReader->readwait.wakeOne(); //唤醒所有线程
}

void other_functions::model_init(){ //这里是否可以放到主线程运行

    //初始化rknn_app_context_t
    memset(&rknn_app_ctx, 0, sizeof(rknn_app_context_t));

    //初始化后期处理
    init_post_process();

    //初始化模型资源
    ret = init_yolov8_model(model_path, &rknn_app_ctx);
    if (ret != 0)
    {
        printf("init_yolov8_model fail! ret=%d model_path=%s\n", ret, model_path);
    }
}

void other_functions::model_release(){

    deinit_post_process();

    ret = release_yolov8_model(&rknn_app_ctx);  //反正帧已经加工好并发过去了，释放模型资源也无所谓了
    if (ret != 0)
    {
        printf("release_yolov8_model fail! ret=%d\n", ret);
    }
}


void other_functions::on_pushButton_4_clicked()//确认修改按钮槽函数
{
    // 当需要读取IP地址时（例如在按钮点击事件中）
    QString ipAddress = ui->lineEdit->text();
    // 可以进一步验证IP地址的有效性
    QHostAddress address(ipAddress);
    if (address.protocol() == QAbstractSocket::IPv4Protocol) {
        // IP地址有效，执行你的函数
        std::string ipAddress_string=ipAddress.toStdString();
        emit update_rtsp(ipAddress_string); // 换成信号函数，传递IP变量
        qDebug()<<ipAddress;
    } else {
        QMessageBox::warning(this, "错误", "请输入有效的IPv4地址");
    }
}

void other_functions::on_pushButton_5_clicked()
{
    /*
     * wifi连接（RTSP网络需求）//用网线作为传输介质就不需要
     */
    system("rfkill unblock 2");//确保 WiFi 硬件没有被软禁用
    int ret = system("connmanctl connect wifi_f0a882f7c843_423330315f3547_managed_psk");//用 connmanctl 连接指定 WiFi，423330315f3547解码位B301_5G
    if (ret == 0) {
        qDebug() << "WiFi 连接命令执行成功";
    } else {
        qDebug() << "WiFi 连接失败，返回值:" << ret;
    }
}

/*
 * 单轴控制器调试
 */
void other_functions::on_test_0_clicked()//按下“0”按键
{
    emit test_0();
}

void other_functions::on_test_1_clicked()
{
    emit test_1();
}

void other_functions::on_test_2_clicked()
{
    emit test_2();
}

void other_functions::on_test_3_clicked()
{
    emit test_3();
}

void other_functions::on_test_4_clicked()
{
    emit test_4();
    m_waitAnim->showFloatingMessage(this,"启动绝对运动",1000);
}

//回零
void other_functions::on_danzhou_init_clicked()
{
    /*
     * 回零命令和一般命令是分开的，初始化不影响回零
     * 先初始化再回零
    */
    m_waitAnim->showFloatingMessage(this, "单轴控制器回零中...", 2000);
    emit danzhou_init_send();
}

//回复出厂设置
void other_functions::on_SB_danzhou_clicked()
{
    emit Factory_reset_send();
    m_waitAnim->showFloatingMessage(this,"恢复出厂设置中...",2000);
    delayMs(2000);
    m_waitAnim->showFloatingMessage(this,"恢复出厂设置成功",1000);
}

void other_functions::delayMs(int ms)
{
    QEventLoop loop;
    QTimer::singleShot(ms, &loop, &QEventLoop::quit);//singleShot这是一个封装在QTimer的函数，他代表只会在倒计时即ms结束后执行一次下面的函数。
    loop.exec();
}


void other_functions::on_pushButton_6_clicked()
{
    system("chmod +x /M/qtdemo/scaling_frequency.sh");
    system("/M/qtdemo/scaling_frequency.sh -c rk3588"); //当前路径执行可执行程序用./，绝对路径执行可执行程序不用加.
}

void other_functions::test_stop()
{
    qDebug() << "收到暂停信号...";

    if (videoReader) {
        videoReader->pause();  // 只暂停，不停止线程
    }

    m_threadPool->waitForDone(2000);

    qDebug() << "性能测试已暂停";
}

void other_functions::test_restart()
{
    qDebug() << "收到恢复信号...";

    if (videoReader) {
        videoReader->resume();  // 恢复解码
    }

    qDebug() << "性能测试已恢复";

}

void other_functions::test_quit()
{
    qDebug() << "性能测试关闭中...";

    // 1. 暂停解码（不再产生新帧，但线程保持等待状态）
    if (videoReader) {
        videoReader->pause();  // 暂停，不停止线程
    }

    // 2. 等待线程池任务完成
    m_threadPool->waitForDone(2000);

    // 4. 释放模型资源
    model_release();

    // 5. 重置按钮状态
    isTestButton = false;
    ui->thread_pool_button->setText("性能测试");

    // 6. 重置图像
    if (mainWindow) {
        mainWindow->showImageLabel();
    }

    qDebug() << "性能测试已停止...";
}




