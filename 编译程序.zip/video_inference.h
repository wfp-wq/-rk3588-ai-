#ifndef VIDEO_INFERENCE_H
#define VIDEO_INFERENCE_H

#include "Mcommon.h"

//摄像头检测工作类
class VideoInference : public QObject
{
    Q_OBJECT

public:
    explicit VideoInference(QObject *parent = nullptr);
    ~VideoInference();

    //void startInference(cv::Mat& src_frame){Inference(src_frame);} //私有方法的公有接口，不如信号槽方法

    void stop();// 停止线程

signals:
    void updateUI(QImage img,DetectionResults results); // 用于更新UI的信号
    void send(FrameData frameData); //发送给推流线程

private:
    bool m_stop;    // 线程停止标志
    QMutex m_mutex; // 互斥锁
    QElapsedTimer timer;

//private slots: 这个会报错，一定要搞清楚原因
public slots:
    void Inference(FrameData frameData);
};

#endif // VIDEO_INFRENCE_H
