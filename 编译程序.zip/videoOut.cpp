#include "videoOut.h"

VideoOut::VideoOut(QObject *parent): QObject(parent),isRunning(false)
{
    lastTime=0;
    fps=0.0;
    frame_count=0;
}

void VideoOut::Out(FrameData frameData, DetectionResults results)
{
    // ========== 解引用 shared_ptr 获取图像 ==========
    cv::Mat& frame = *(frameData.frame);

    currentTime = QDateTime::currentMSecsSinceEpoch();

    qDebug()<<"三线程正在工作中...";

    isRunning=true;

    // 第一次调用初始化
    if(lastTime == 0) {
        lastTime = currentTime;
        record_frame_number = frameData.current_frame;
        frameCount = 0;
    }

    // 计算帧率 (每10帧更新一次)
    frameCount++; //不管这一帧显没显示，都记数

    //重新设置第一帧
    if(abs(frameData.current_frame - record_frame_number) > 100)
    {
        record_frame_number = frameData.current_frame;
    }
    //实际测试，确实旧帧不再显示
    if(frameData.current_frame < record_frame_number)
    {
        return;
    }

    qDebug()<<"第"<<frameData.current_frame<<"帧";
    record_frame_number = frameData.current_frame;

    //帧数计算方式：
    if(frameCount >= 20) {
        qint64 timeDiff = currentTime - lastTime;
        fps = frameCount * 1000.0 / timeDiff;
        frameCount = 0;
        lastTime = currentTime;
        qDebug()<<"fps: "<<fps;
    }

    // ========== 使用 frame（解引用后的 cv::Mat）==========
    cv::putText(frame, cv::format("Actual FPS: %.1f FPS", fps),
                cv::Point(10, 60), cv::FONT_HERSHEY_SIMPLEX,
                2, cv::Scalar(0, 0, 255), 6);

    QImage resultImage(frame.data, frame.cols, frame.rows,
                       frame.step, QImage::Format_RGB888);
    emit updateUI(resultImage.copy(), results);  //更新UI线程画面（必须深拷贝）
}

void VideoOut::frame_receive(FrameData frameData)
{
    m_frameCache1.append(frameData);
    frame_count++;
    if(frame_count == 30)
    {
        frame_count = 0;
        sortFrames();
        m_frameCache2 = m_frameCache1;
        m_frameCache1.clear();
    }
}

void VideoOut::sortFrames() {
    std::sort(m_frameCache1.begin(), m_frameCache1.end(),
              [](const FrameData& a, const FrameData& b) {
                  return a.current_frame < b.current_frame;
              });
}
