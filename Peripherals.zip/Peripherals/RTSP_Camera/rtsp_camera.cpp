#include "rtsp_camera.h"


RTSP_Camera::RTSP_Camera(QObject *parent):QObject(parent)
{

}
RTSP_Camera::~RTSP_Camera()
{
}

QString RTSP_Camera::CoordinateMapDistance(int coordinate_x)
{
    int distance=(int)(coordinate_x*0.64);//乘以 0.64，算出电机实际需要转动的距离（比如 64mm）
    //Modbus 协议要求的十六进制格式，这句话的意思是“把 distance 变量，格式化为 4位宽度，使用 16进制，不够的地方用 '0' 补齐”。
    QString Distance_hexStr = QString("%1").arg(distance, 4, 16, QChar('0')).toUpper(); //指定宽度为 4 并补零，适用于Modbus 协议
    //（01代表呼叫 1 号设备（电机），06 代表写单个寄存器，把数据存在第 16 号格子（0x0010）里，Distance_hexStr计算出来是0064）
    QString Complete_hexStr="01 06 00 10 "+Distance_hexStr; //移动距离，“01 06 00 10 00 ～”
    //加上“防伪标签”（CRC16 校验），避免数据被其他因素混乱
    QString hexStr = danzhou_c.crc16Modbus(Complete_hexStr).toHex(' ').toUpper();
    return hexStr;   
}



