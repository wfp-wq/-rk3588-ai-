#include <QObject>
#include <QByteArray>
#include <QDebug>
#include <QTimer>
#include <QEventLoop>
#include "../danzhou/danzhou.h"


class RTSP_Camera:public QObject{
    Q_OBJECT

public:
    explicit RTSP_Camera(QObject *parent = nullptr);
    ~RTSP_Camera();

public slots:
    QString CoordinateMapDistance(int coordinate);
private:
    DanZhouControl danzhou_c;

};
