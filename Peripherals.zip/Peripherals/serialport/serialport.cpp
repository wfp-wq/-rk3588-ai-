#include "serialport.h"

SerialPort::SerialPort(QObject *parent):QObject(parent)
{
    serialPort = new QSerialPort(this);
    connect(serialPort,SIGNAL(readyRead()),this,SLOT(onReadyRead()));//读取其他设备发送来的内容并存储到data中
    serialport_init();
    delayMs(10);
    serialport_open();
}

SerialPort::~SerialPort()
{
}

void SerialPort::serialport_init()
{
    //设置要打开的串口的名字
    serialPort->setPortName("/dev/ttyS3");//调用开发板上的板载串口“ttyS3”

    //设置波特率
    serialPort->setBaudRate(QSerialPort::Baud115200);

    //设置停止位
    serialPort->setStopBits(QSerialPort::OneStop);

    //设置数据位
    serialPort->setDataBits(QSerialPort::Data8);

    //设置校验位
    serialPort->setParity(QSerialPort::NoParity);

    //设置流控为无流控
    serialPort->setFlowControl(QSerialPort::NoFlowControl);
}

void SerialPort::serialport_open()
{
    if(!serialPort->open(QIODevice::ReadWrite)){
        qDebug()<<"error:串口打开失败可能被占用了";
        return;
    }
}

void SerialPort::serialport_close()
{
    serialPort->close();
}

void SerialPort::delayMs(int ms)
{
    QEventLoop loop;
    QTimer::singleShot(ms, &loop, &QEventLoop::quit);
    loop.exec();
}

void SerialPort::onReadyRead()
{
    auto data = serialPort->readAll();//从串口线中读接收到的数据
    //displayHex();
}

/*
 * 发送16进制数据
 */
void SerialPort::sendHexData(QString dataStr)
{
    QByteArray hexbyte = QByteArray::fromHex(dataStr.toUtf8());//先转换成UTF8再转成二进制QByteArray，然后在写进串口线
    serialPort->write(hexbyte);//“写”到了串口线里，顺着线跑到了另一头连接的设备（通常是单片机）的内存里，等着被它读取和处理。
}
