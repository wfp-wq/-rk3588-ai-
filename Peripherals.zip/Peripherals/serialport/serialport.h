//serialwindow和此串口工具类并不互通

#ifndef SERIALPORT_H
#define SERIALPORT_H

#include <QSerialPort> //串口类
#include <QSerialPortInfo> //串口信息类
#include <QObject>
#include <QEventLoop>
#include <QTimer>
#include <QByteArray>
#include <QDebug>

class SerialPort : public QObject{
    Q_OBJECT

public:
    explicit SerialPort(QObject *parent = nullptr);
    ~SerialPort();

    void serialport_init();
    void serialport_open();
    void serialport_close();
    void sendHexData(QString dataStr);

    //标志位
    bool isSerialOpen;  //判断是否启用串口
    QSerialPort *serialPort;

public slots:
    void delayMs(int ms);
    void onReadyRead();
};

#endif //SERIALPORT_H
