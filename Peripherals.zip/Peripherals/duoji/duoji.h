#include <QFile>
#include <QDir>
#include <QDebug>
#include <QEventLoop>
#include <QByteArray>
#include <QTimer>

class DuoJi{

public:
    explicit DuoJi();
    ~DuoJi();

    void left_or_right_move(int x);
    bool checkPwm2ChannelExported();
    void P0_C6_init();

public:
    //水平方向PWM（pwmchip3-P0_C6）
    QFile file;
    int current_duty_cycle;
    int target_duty_cycle;
    int Xs;
    int k;
};
