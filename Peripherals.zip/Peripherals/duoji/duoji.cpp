#include "duoji.h"

DuoJi::DuoJi()
{
    P0_C6_init();
}


void DuoJi::left_or_right_move(int x)
{
    if(!file.open(QIODevice::WriteOnly))
    {
        qDebug()<<"error:PWM0的pwn0节点不存在！";
        return;
    }

    //向右转
    if(x < Xs)
    {
        target_duty_cycle= (Xs-x)*k; //这里其实是德尔塔

        if(current_duty_cycle-target_duty_cycle<1600000)  //默认1600000
        {
            qDebug()<<"超过x轴最大转动角度!";
        }else{
            //更新当前脉宽和当前初始坐标
            current_duty_cycle=current_duty_cycle-target_duty_cycle;
            qDebug()<<"current_duty_cycle2:"<<current_duty_cycle;
        }
    }

    //向左转（面对屏幕而言的左）//面对屏幕向左，在画面中向右，X变大
    if(x > Xs)
    {
        //更新当前脉宽和当前初始坐标(这里是反逻辑，我不知道为什么默认图像是反的)
        target_duty_cycle= (x-Xs)*k;

        if(current_duty_cycle+target_duty_cycle>2300000) //默认2300000
        {
            qDebug()<<"超过x轴最大转动角度!";
        }else{
            current_duty_cycle=current_duty_cycle+target_duty_cycle;
        }
    }

    Xs=x;
    //将int转换为字符串格式的QByteArray
    QByteArray buf = QByteArray::number(current_duty_cycle);

    file.write(buf);

    file.close();
}

//1600000——2300000
bool DuoJi::checkPwm2ChannelExported() {
    QDir dir("/sys/class/pwm/pwmchip3");
    return dir.exists("pwm0");
}

DuoJi::~DuoJi()
{
    system("echo 0 > /sys/class/pwm/pwmchip2/pwm0/enable"); //禁用PWM输出
    system("echo 0 > /sys/class/pwm/pwmchip2/unexport"); //移除创建的PWM通道
}

void DuoJi::P0_C6_init()
{
    // 在导出前检查
    if (checkPwm2ChannelExported()) {
        qDebug() << "警告：PWM2通道pwm0已导出，先执行unexport";
        system("echo 0 > /sys/class/pwm/pwmchip2/pwm0/enable");
        system("echo 0 > /sys/class/pwm/pwmchip2/unexport");
    }

    //pwmchip3的pwm0初始化
    system("echo 0 > /sys/class/pwm/pwmchip2/export");
    system("echo 20000000 > /sys/class/pwm/pwmchip2/pwm0/period"); //设置20ms一个周期，这里的单位为ns
    system("echo 1950000 > /sys/class/pwm/pwmchip2/pwm0/duty_cycle"); //复位中间度
    system("echo normal > /sys/class/pwm/pwmchip2/pwm0/polarity");
    system("echo 1 > /sys/class/pwm/pwmchip2/pwm0/enable"); //使能

    file.setFileName("/sys/class/pwm/pwmchip2/pwm0/duty_cycle"); //后面只对duty进行操作

    current_duty_cycle=1950000;
    target_duty_cycle=0;
    k=1200;
    Xs=500;
}


