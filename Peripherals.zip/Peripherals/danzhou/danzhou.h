#include <QObject>


class DanZhouControl:public QObject
{
    Q_OBJECT
public:
    explicit DanZhouControl(QObject *parent = nullptr);
    ~DanZhouControl();

    QByteArray crc16Modbus(QString hexStr);
};
