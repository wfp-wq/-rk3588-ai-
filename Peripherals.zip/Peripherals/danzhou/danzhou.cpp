#include "danzhou.h"

DanZhouControl::DanZhouControl(QObject *parent):QObject(parent)
{

}

DanZhouControl::~DanZhouControl()
{
}

//输入16进制字符串，返回modbus协议格式的16进制字节
QByteArray DanZhouControl::crc16Modbus(QString hexbyteStr) {
    hexbyteStr.remove(" ");//去除空格
    QByteArray hexbyte = QByteArray::fromHex(hexbyteStr.toUtf8());
    QByteArray hexbyte_save=hexbyte;
    quint16 crc = 0xFFFF;
    for (int i = 0; i < hexbyte.length(); i++) {
        crc ^= static_cast<quint16>((quint8)hexbyte[i]);
        for (int j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc = (crc >> 1) ^ 0xA001;
            } else {
                crc = (crc >> 1);
            }
        }
    }

    // 将quint16的CRC转换为QByteArray（小端模式）
    QByteArray crcBytes;
    // 低字节（CRC的低8位）
    crcBytes.append(static_cast<quint8>(crc & 0xFF));
    // 高字节（CRC的高8位）
    crcBytes.append(static_cast<quint8>((crc >> 8) & 0xFF));

    // 将原始数据与CRC拼接后返回
    return hexbyte_save + crcBytes;
}

