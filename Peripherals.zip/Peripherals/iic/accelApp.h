// #ifdef __cplusplus
// extern "C" {
// #endif

// #ifdef __cplusplus
// }
// #endif

#ifndef ACCELAPP_H
#define ACCELAPP_H

#include <QDebug>
#include<QElapsedTimer>

extern int g_stop_flag;  // 0=运行，1=停止

class SH3001 : public QObject{
    Q_OBJECT

public:
float x_v0;
float x_v1;
float x_a;
float t;

public:
explicit SH3001(QObject *parent = nullptr);
~SH3001() override; // 虚析构函数必须实现
// 函数声明（与实际定义一致）
void sh3001_init();
void sh3001_Acc();

};

#endif
