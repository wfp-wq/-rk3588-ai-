/*******************************************************************************
Guangzhou Xingyi Electronic  Technology Co., Ltd 2021-2030. All rights reserved.
* @brief         accel.c
* @author        正点原子Linux团队
* @date          2023-06-26
* @link          http://www.openedv.com/forum.php
********************************************************************************/
#include "accelApp.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#include <dirent.h>
#include <string.h>

#define GSENSOR_IOCTL_MAGIC		'a'
#define GSENSOR_IOCTL_CLOSE		_IO(GSENSOR_IOCTL_MAGIC, 0x02)
#define GSENSOR_IOCTL_START		_IO(GSENSOR_IOCTL_MAGIC, 0x03)
#define SENSOR_ON			1
#define SENSOR_OFF			0

int g_stop_flag = 0; // 定义并初始化，分配内存

//全局变量在程序运行期间只有一份内存空间，所有函数对它的访问和修改都是直接操作这一块内存
struct input_event ev = {0};
DIR *dir = NULL;
int accel_x, accel_y, accel_z;
int abs_x, abs_y, abs_z;
int fd = -1;
int misc_fd = -1;
int ret = -1;
char buf[64] = {0};
int x_off = 0;
int y_off = 0;
int z_off = 0;


SH3001::SH3001(QObject *parent) : QObject(parent) {}

SH3001::~SH3001() {
    // 析构函数实现（即使为空）
}

void SH3001::sh3001_init()
{
    x_v0=0.00;
    x_v1=0.00;
    x_a=0.00;

	setbuf(stdout, NULL);
	/* 1.先执行校准 */
	/* 校准之前必须让开发板或手机等设备水平静止放置(Z轴垂直) */
	printf(">>> 校准之前开发板必须处于水平放置状态 <<<\n");
	printf(">>> 1秒后开始执行校准 <<<\n");
	sleep(1);

    fd = open("/sys/class/sensor_class/accel_calibration", O_RDWR); //和PWM操作一样，都是对于设备树的节点接口进行操作（对文件读写）
	if (fd < 0) {
		printf("打开accel_calibration失败!\n");
        return;
	}
	ret = write(fd, "1", 1);//写1进行校准
	if (ret != 1) {	//校准失败!
		close(fd);
		printf("执行校准失败!\n");
        return;
	}
	usleep(100*1000);
	printf(">>> 校准完成 <<<\n");

	/* 2.读取校准值 */
	ret = read(fd, buf, sizeof(buf));
	close(fd);
	if (ret < 18) {	//读取失败
		printf("读取校准值失败!\n");
        return;
	}
	usleep(100*1000);

    x_off = atoi(&buf[18]);
    y_off = atoi(strchr(buf, ',') + 2);
    z_off = atoi(strrchr(buf, ',') + 2);
	printf("offset: [%d, %d, %d]\n", x_off, y_off, z_off);

	/* 3.打开加速计设备 */
	misc_fd = open("/dev/mma8452_daemon", O_RDWR);
	if (misc_fd < 0) {
		printf("打开/dev/mma8452_daemon设备失败!\n");
        return;
	}

	dir = opendir("/dev/input");
	if(dir != NULL) {
		struct dirent *de = NULL;

		memset(buf, 0x0, sizeof(buf));
		while((de = readdir(dir))) {
			if(strncmp(de->d_name, "event", 5))//判断是不是eventX设备节点
				continue;
			fd = openat(dirfd(dir), de->d_name, O_RDONLY);
			if(fd < 0)      //打开失败
				continue;

			if (ioctl(fd, EVIOCGNAME(sizeof(buf) - 1), &buf) < 1)
				buf[0] = '\0';//重置为空字符串
			if (strcmp(buf, "gsensor")) {//如果不是重力加速计传感器
				close(fd);
				continue;
			}
			closedir(dir);//关闭文件夹

			goto start_read;//跳转到start_read
		}

		// 没有找到加速计传感器
		closedir(dir);
		goto err_out2;
	}
	else
		goto err_out2;

start_read:
	//传感器启动
	if (ioctl(misc_fd, GSENSOR_IOCTL_START) < 0) {
		printf("ioctl[/dev/mma8452_daemon] failed!\n");
	}

	accel_x = accel_y = accel_z = 0;

    //for ( ; ; ) {   // 等价于 while(1)，表示无限循环

    return;

// 没有任何跳转或return，程序会继续往下执行err_out
err_out4:
	ioctl(misc_fd, GSENSOR_IOCTL_CLOSE);//停止传感器上报数据

err_out3:
	close(fd);
err_out2:
	close(misc_fd);
}

void SH3001::sh3001_Acc()
{

    x_v0=0.00;
    x_v1=0.00;
    x_a=0.00;

    QElapsedTimer timer;
    timer.start();

 while(g_stop_flag == 0)
 {
    if (read(fd, &ev, sizeof(ev)) != sizeof(ev)) {
        printf("read failed!\n");
        goto err_out4;
    }

    if (ev.type == EV_ABS) {
        if (ev.code == ABS_X)//x轴加速度
            accel_x = ev.value; //accel_x 不是位移量，而是指 X 轴方向的加速度（acceleration in X-axis）
        else if (ev.code == ABS_Y)//y轴加速度
            accel_y = ev.value;
        else if (ev.code == ABS_Z)//z轴加速度
            accel_z = ev.value;
    }
    else if (ev.type == EV_SYN) {
        if (ev.code == SYN_REPORT) {//同步事件
            // 按照+-2G量程来计算 2^15 = 32768
            // 32768 / 2 = 16384 / 1g重力(9.81m/s^2)
            // 16384 / 9.81 = 1670左右 取值1600
            abs_x = accel_x - x_off;
            abs_y = accel_y - y_off;
            abs_z = accel_z - z_off;
            printf("\n");
            printf("%f	%f	%f\n", (float)abs_x / 16384 * 9.8, (float)abs_y / 16384 * 9.8, (float)abs_z / 16384 * 9.8);
            printf("\n");

            // a=德尔塔v/t
            // v=at;

            if (timer.elapsed() >= 1000) { //每一秒更新一次，这个限制可以去掉
                //fps = frameCount * 1000.0 / timer.elapsed();
                //frameCount = 0;
                timer.restart();
            }

            //还是得用int型数据，要不然误差太大 //减速的过程除非动作幅度大否则捕获不到
            t=timer.elapsed()/1000.00; //不进行强制类型转换的话，int/int小于1就是0

            float save_last_x_a=0.00;

            if(x_a!=0.00) save_last_x_a=x_a; //记录上一次的加速度值

            x_a=(float)abs_x / 16384 * 9.8;
            printf("加速度a：%.2f m/s^2\n",x_a);

            if(abs(x_a-save_last_x_a)<0.05)
            {
            }
            else{
            x_v1=x_v0+x_a*t;
            x_v0=x_v1;
            }

            if(abs(x_v1)<1)
            {
                printf("%d m/s",(int)x_v1);
            }else{
                printf("%.2f m/s\n",x_v1);
            }
        }
    }

    //usleep(50*1000); // 等待50毫秒（控制采样频率约20Hz）
    usleep(1*1000);
 }
    goto err_out5;

//进入这个error4处理的话只能运行一次，下一次得重新初始化
err_out4:
    ioctl(misc_fd, GSENSOR_IOCTL_CLOSE);//停止传感器上报数据
    printf("停止sh3001传感器上传1\n");

err_out5:
    printf("停止sh3001传感器上传2\n");
    return;
}


