#ifndef DANZHOU_TEST_UI_H
#define DANZHOU_TEST_UI_H

#include <QWidget>

namespace Ui {
class danzhou_test_ui;
}

class danzhou_test_ui : public QWidget
{
    Q_OBJECT

public:
    explicit danzhou_test_ui(QWidget *parent = nullptr);
    ~danzhou_test_ui();

signals:
    void command_send(QString command);

private slots:
    void on_pushButton_clicked();

private:
    Ui::danzhou_test_ui *ui;
};

#endif // DANZHOU_TEST_UI_H
