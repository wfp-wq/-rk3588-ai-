#include "danzhou_test_ui.h"
#include "ui_danzhou_test_ui.h"

danzhou_test_ui::danzhou_test_ui(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::danzhou_test_ui)
{
    ui->setupUi(this);
}

danzhou_test_ui::~danzhou_test_ui()
{
    delete ui;
}

void danzhou_test_ui::on_pushButton_clicked()
{
    QString command=ui->comboBox->currentText();

    switch (command.toInt()){
        case 10:
            emit command_send("01 06 00 10 00 0A");
        case 30:
            emit command_send("01 06 00 10 00 1E");
        case 50:
            emit command_send("01 06 00 10 00 32");
        case -10:
            emit command_send("");
        case -30:
            emit command_send("");
        case -50:
            emit command_send("");
        default:
            break;
    }
    emit command_send(command);
}

