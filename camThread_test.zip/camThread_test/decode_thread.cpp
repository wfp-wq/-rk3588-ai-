#include "decode_thread.h"

decode_Thread::decode_Thread(FrameQueue* queue,QObject* parent)
    : QThread{parent}
{
    // 在函数体内赋值
    this->frameQueue = queue;
    this->mppdec = nullptr;
    this->m_stop = false;
}

decode_Thread::~decode_Thread()
{
    qDebug() << "[decode_Thread] 析构函数被调用";
    // 只在线程还在运行时才停止和等待
    if (isRunning()) {
        stop();
        wait();
    }
    qDebug() << "[decode_Thread] 析构函数结束";
}

//mpp硬件解码线程
void decode_Thread::run()
{
    qDebug() << "[解码线程] 启动";

    // 初始化 MPP 解码器
    std::string rtsp = "rtsp://admin:S1234567890@192.168.1.2:554/1/1";
    mppdec = new MppRtspDecoder(rtsp);
    if (mppdec->init() != 0) {
        qDebug() << "[解码线程] MPP初始化失败";
        return;
    }
    qDebug() << "[解码线程] MPP初始化成功";

    cv::Mat src_frame;
    cv::Mat rgb_frame;  // 新增
    src_frame.create(cv::Size(1280, 720), CV_8UC3);

    // ========== 优化：预分配所有缓冲区 ==========
    cv::Mat resized(720, 720, CV_8UC3);      // 预分配
    cv::Mat flipped(720, 720, CV_8UC3);      // 预分配

    //这里只要程序不强制关闭，或者stop函数没被调用，就一直循环解码下去
    while (!m_stop) {
        int ret = mppdec->decode_simple(src_frame);
        if (ret < 0 || src_frame.empty()) {
            if (m_stop) break;
            continue;
        }

        // 直接使用预分配的 Mat
        cv::resize(src_frame, resized, resized.size());
        cv::cvtColor(resized, resized, cv::COLOR_BGR2RGB);
        cv::flip(resized, flipped, 1);

        // 需要 clone，因为队列是跨线程的
        frameQueue->push(flipped.clone());
    }

    qDebug() << "[解码线程] 开始清理 MPP 资源";
    if (mppdec) {
        delete mppdec;      // 再删除对象
        mppdec = nullptr;
    }
    qDebug() << "[解码线程] MPP 资源已清理";

    qDebug() << "[解码线程] 结束";
}

void decode_Thread::stop()
{
    m_stop = true;
}
