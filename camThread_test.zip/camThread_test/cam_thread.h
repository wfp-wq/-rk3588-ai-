#ifndef CAM_THREAD_H
#define CAM_THREAD_H

#include <QThread>
#include <QMutex>
#include<QImage>
#include "yolov8_img/yolov8.h"
#include<QElapsedTimer>
#include<QMutexLocker>
#include <QObject>
#include<QRunnable>
#include <vector>
#include <iostream>
#include <QDebug>
#include "decode_thread.h"
#include "infer_thread.h"
#include "frame_queue.h"

#include "image_utils.h"
#include "file_utils.h"
#include "image_drawing.h"
#include <opencv2/opencv.hpp>


//#include "Peripherals/iic/accelApp.h" //加速度传感器
#include "Mpp/mpprtspdecoder.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#include <dirent.h>
#include <string.h>
#include <QTimer>


using std::vector;
using namespace cv;
using namespace std;

//摄像头检测工作类
class CamThread : public QObject, public QRunnable
{
    Q_OBJECT
public:
    explicit CamThread(QObject *parent = nullptr);
    ~CamThread();

    void stop();// 停止线程

signals:
    void updateUI(QImage img,DetectionResults results); // 用于更新UI的信号
    void newCoordinatesReceived(int x_mid,int y_mid);
    void map_and_move_send(int target_x);

protected:
    void run() override; // 线程执行函数

private:
    bool m_stop;    // 线程停止标志
    QMutex m_mutex; // 互斥锁
    int printfCount = 0;
    int target_x,target_y;
    FrameQueue* frameQueue;
    decode_Thread* decoderWorker;
    infer_Thread* inferWorker;

public:
    string rtsp1_ip;
    bool isCameraThreadFinished;

public slots:
    void update_rtsp(string rtsp_ip);
};

#endif // CAM_THREAD_H
