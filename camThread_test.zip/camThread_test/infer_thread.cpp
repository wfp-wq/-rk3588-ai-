#include "infer_thread.h"
#include "qtimer.h"

infer_Thread::infer_Thread(FrameQueue* queue, QObject* parent)
    : QThread(parent)
    , frameQueue(queue)
    , m_stop(false)
    , inferenceInited(false)
    , cropCount(0)
    , weedCount(0)
    , targetCount(0)
    , rga_call_count(0)
    ,last_sent_x(0)
    ,last_sent_y(0)
{
    memset(&rknn_app_ctx, 0, sizeof(rknn_app_context_t));
}

infer_Thread::~infer_Thread()
{
    qDebug() << "[infer_Thread] 析构函数被调用";
    stop();
    wait();
    releaseInference();
}

int infer_Thread::initInference()
{
    const char* model_path = "./model/yolov8.rknn";

    init_post_process();

    int ret = init_yolov8_model(model_path, &rknn_app_ctx);
    if (ret != 0) {
        qDebug() << "[推理线程] 模型初始化失败:" << model_path;
        return -1;
    }

    qDebug() << "[推理线程] 模型初始化成功";
    inferenceInited = true;
    return 0;
}

void infer_Thread::releaseInference()
{
    if (inferenceInited) {
        deinit_post_process();
        release_yolov8_model(&rknn_app_ctx);
        inferenceInited = false;
        qDebug() << "[推理线程] 模型资源已释放";
    }
}

void infer_Thread::run()
{
    qDebug() << "[推理线程] 启动";

    if (initInference() != 0) {
        qDebug() << "[推理线程] 初始化失败，退出";
        return;
    }

    image_buffer_t src_image;
    memset(&src_image, 0, sizeof(image_buffer_t));
    object_detect_result_list od_results;
    DetectionResults results;

    QElapsedTimer timer;
    timer.start();
    int frameCount = 0;
    double fps = 0.0;

    cv::Mat frame;
    // 绿色范围（HSV），可以根据实际环境调整
    cv::Scalar lower_green(35, 50, 50);   // 绿色下限 H:35-85
    cv::Scalar upper_green(85, 255, 255); // 绿色上限
    // 2. 对整张图像进行绿色检测（HSV颜色空间）
    cv::Mat hsv, green_mask;


    while (!m_stop) {
        // ========== 1. 从队列取帧 ==========
        if (!frameQueue->pop(frame, 100)) {
            if (m_stop || frameQueue->isStopped()) break;
            continue;
        }

        //------------------根据官方demo的yolov8推理代码---------------------------//
        // ========== 2. 填充 src_image ==========
        src_image.height = frame.rows;
        src_image.width = frame.cols;
        src_image.width_stride = frame.step[0];
        src_image.virt_addr = frame.data;
        src_image.format = IMAGE_FORMAT_RGB888;
        src_image.size = frame.total() * frame.elemSize();

        // ========== 推理代码 ==========
        image_buffer_t dst_img;
        letterbox_t letter_box;
        rknn_input inputs[rknn_app_ctx.io_num.n_input];
        rknn_output outputs[rknn_app_ctx.io_num.n_output];
        const float nms_threshold = NMS_THRESH;
        const float box_conf_threshold = BOX_THRESH;
        int bg_color = 114;

        memset(&od_results, 0x00, sizeof(od_results));
        memset(&letter_box, 0, sizeof(letterbox_t));
        memset(&dst_img, 0, sizeof(image_buffer_t));
        memset(inputs, 0, sizeof(inputs));
        memset(outputs, 0, sizeof(outputs));

        dst_img.width = rknn_app_ctx.model_width;
        dst_img.height = rknn_app_ctx.model_height;
        dst_img.format = IMAGE_FORMAT_RGB888;
        dst_img.size = get_image_size(&dst_img);
        dst_img.virt_addr = (unsigned char *)malloc(dst_img.size);
        if (dst_img.virt_addr == NULL) {
            continue;
        }

        int ret = convert_image_with_letterbox(&src_image, &dst_img, &letter_box, bg_color);
        if (ret < 0) {
            free(dst_img.virt_addr);
            continue;
        }

        inputs[0].index = 0;
        inputs[0].type = RKNN_TENSOR_UINT8;
        inputs[0].fmt = RKNN_TENSOR_NHWC;
        inputs[0].size = rknn_app_ctx.model_width * rknn_app_ctx.model_height * rknn_app_ctx.model_channel;
        inputs[0].buf = dst_img.virt_addr;

        ret = rknn_inputs_set(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_input, inputs);
        if (ret < 0) {
            free(dst_img.virt_addr);
            continue;
        }
        free(dst_img.virt_addr);

        ret = rknn_run(rknn_app_ctx.rknn_ctx, nullptr);
        if (ret < 0) continue;

        memset(outputs, 0, sizeof(outputs));
        for (int i = 0; i < rknn_app_ctx.io_num.n_output; i++) {
            outputs[i].index = i;
            outputs[i].want_float = (!rknn_app_ctx.is_quant);
        }
        ret = rknn_outputs_get(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_output, outputs, NULL);
        if (ret < 0) continue;

        post_process(&rknn_app_ctx, outputs, &letter_box, box_conf_threshold, nms_threshold, &od_results);
        rknn_outputs_release(rknn_app_ctx.rknn_ctx, rknn_app_ctx.io_num.n_output, outputs);
        //------------------官方demo推理代码结束---------------------------//

        // ========== 识别农作物（只记录，不画框）==========
        std::vector<cv::Rect> crop_boxes;
        for (int i = 0; i < od_results.count; i++) {
            object_detect_result* det_result = &(od_results.results[i]);
            QString className = QString::fromUtf8(coco_cls_to_name(det_result->cls_id));

            if (className == "crop") {
                cv::Rect crop_rect(
                    det_result->box.left,
                    det_result->box.top,
                    det_result->box.right - det_result->box.left,
                    det_result->box.bottom - det_result->box.top
                    );
                crop_boxes.push_back(crop_rect);
                cropCount++;
                // 不画农作物框，节省开销
            }
        }

        // ========== 跳帧处理：每5帧做一次完整绿色检测 ==========
        cv::Rect best_weed;
        double max_area = 0;
        int weed_count = 0;
            // 完整绿色检测
            cv::cvtColor(frame, hsv, cv::COLOR_RGB2HSV);
            cv::inRange(hsv, lower_green, upper_green, green_mask);

            // 排除农作物区域内的绿色
            for (const auto& crop_rect : crop_boxes) {
                cv::rectangle(green_mask, crop_rect, cv::Scalar(0), -1);
            }
            // 形态学操作，这里(9,9)设置的是形态学大小，即两个距离相近的是否合并
            cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(9, 9));
            cv::morphologyEx(green_mask, green_mask, cv::MORPH_OPEN, kernel);
            cv::morphologyEx(green_mask, green_mask, cv::MORPH_CLOSE, kernel);

            // 找出绿色区域的轮廓
            std::vector<std::vector<cv::Point>> contours;
            cv::findContours(green_mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

            for (const auto& contour : contours) {
                double area = cv::contourArea(contour);
                if (area > 200) {
                    cv::Rect weed_rect = cv::boundingRect(contour);
                    weed_count++;

                    // 画杂草框（红色）
                    draw_rectangle(&src_image, weed_rect.x, weed_rect.y,
                                   weed_rect.width, weed_rect.height, 0xFF0000, 2);

                    char text[256];
                    sprintf(text, "weed %d", weed_count);
                    draw_text(&src_image, text, weed_rect.x, weed_rect.y - 20, 0xFF0000, 10);

                    if (area > max_area) {
                        max_area = area;
                        best_weed = weed_rect;
                    }
                }
            }
        // 只发送最大的杂草坐标,一个图像能识别出多种，那我到底发哪一个给他呢
        if (max_area > 0) {
            int current_x = best_weed.x + best_weed.width / 2;
            int current_y = best_weed.y + best_weed.height / 2;

            if (current_x != last_sent_x || current_y != last_sent_y) {
                last_sent_x = current_x;
                last_sent_y = current_y;

                QTimer::singleShot(2000, this, [this, current_x]() {
                    emit move_send(current_x);
                });
            }
        }

        // ========== 显示FPS ==========
        frameCount++;
        if (timer.elapsed() >= 1000) {
            fps = frameCount * 1000.0 / timer.elapsed();
            frameCount = 0;
            timer.restart();
        }

        cv::putText(frame, cv::format("FPS: %.1f", fps),
                    cv::Point(10, 50), cv::FONT_HERSHEY_SIMPLEX,
                    1, cv::Scalar(0, 255, 0), 2);

        // 显示图像
        QImage resultImage = QImage(frame.data, frame.cols, frame.rows,
                                    frame.step, QImage::Format_RGB888).copy();
        results.img = resultImage;
        emit frameProcessed(resultImage, results);

    }

    qDebug() << "[推理线程] 结束";
}


void infer_Thread::stop()
{
    m_stop = true;
}
