/*-------------------------------------------
                Includes
-------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/*-------------------------------------------
                  Main Function
-------------------------------------------*/

#include "cam_thread.h"

CamThread::CamThread(QObject *parent) : QObject(parent),QRunnable(), m_stop(false)
{
    setAutoDelete(false);//线程结束，任务自动销毁
    rtsp1_ip="";
    isCameraThreadFinished=false;
}

CamThread::~CamThread()
{
    stop();
}

void CamThread::stop()
{
    QMutexLocker locker(&m_mutex);
    m_stop = true;
}

//测试摄像头线程，只能达到30帧，起测试作用
void CamThread::run()
{
    qDebug() << "[CamThread] 启动";

    m_stop = false;
    isCameraThreadFinished = false;
    //采用队列加两个线程串行来实现
    // 1. 创建队列
    FrameQueue* frameQueue = new FrameQueue(5);

    // 2. 创建工作线程
    decoderWorker = new decode_Thread(frameQueue);
    inferWorker = new infer_Thread(frameQueue);

    // 3. 连接信号：推理结果 → CamThread → 主线程
    connect(inferWorker, &infer_Thread::frameProcessed,
            this, [this](QImage img, DetectionResults results) {
                emit updateUI(img, results);
            });

    connect(inferWorker, &infer_Thread::move_send,
            this, [this](int x) {
                emit map_and_move_send(x);
            });

    // 4. 启动工作线程
    decoderWorker->start();
    inferWorker->start();

    qDebug() << "[CamThread] 工作线程已启动";

    // 5. 等待停止信号
    while (!m_stop) {
        QThread::msleep(100);
    }

    qDebug() << "[CamThread] 停止，开始清理...";

    // 6. 停止队列（唤醒阻塞的线程）
    frameQueue->stop();
    qDebug() << "[CamThread] 队列已停止";

    // 7. 停止工作线程，这里stop是自己写好的停止函数
    decoderWorker->stop();
    inferWorker->stop();

    // 8. 等待线程结束
    decoderWorker->wait();
    qDebug() << "[CamThread] 解码线程已结束";
    inferWorker->wait();
    qDebug() << "[CamThread] 推理线程已结束";

    // 9. 清理资源 - 逐步执行并打印
    qDebug() << "[CamThread] 准备删除 decoderWorker";
    delete decoderWorker;
    qDebug() << "[CamThread] decoderWorker 已删除";

    delete inferWorker;
    qDebug() << "[CamThread] inferWorker 已删除";

    delete frameQueue;
    qDebug() << "[CamThread] frameQueue 已删除";

    isCameraThreadFinished = true;
    qDebug() << "[CamThread] 清理完成，线程结束";
}


void CamThread::update_rtsp(string rtsp_ip)
{
    rtsp1_ip=rtsp_ip;
    cout<<rtsp_ip;
}
