#ifndef DECODE_THREAD_H
#define DECODE_THREAD_H

#include <QObject>
#include <QThread>
#include <QDebug>
#include "frame_queue.h"
#include "Mpp/mpprtspdecoder.h"
#include "drmrga.h"
#include "image_utils.h"
#include <unistd.h>        // 添加这行 - 定义 close 函数
#include "dma_alloc.h"

// DMA 堆路径
#define DMA_HEAP_DMA32_UNCACHE_PATH "/dev/dma_heap/system-uncached-dma32"

class decode_Thread : public QThread
{
    Q_OBJECT
public:
    explicit decode_Thread(FrameQueue* queue,QObject *parent = nullptr);
    ~decode_Thread();
    void run() override;
    void stop();

private:
    FrameQueue* frameQueue;
    MppRtspDecoder* mppdec;
    bool m_stop;
    int rga_buffer_fd;
    void* rga_buffer_ptr;

signals:
};

#endif // DECODE_THREAD_H
