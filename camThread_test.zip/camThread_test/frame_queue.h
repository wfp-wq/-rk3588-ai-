#ifndef FRAME_QUEUE_H
#define FRAME_QUEUE_H

#include <QQueue>
#include <QMutex>
#include <QWaitCondition>
#include <opencv2/opencv.hpp>
#define MAX_SIZE 3

class FrameQueue
{
public:
    explicit FrameQueue(int maxSize = MAX_SIZE) : maxSize(maxSize), stopped(false) {}

    // 放入帧（生产者调用）
    void push(const cv::Mat& frame) {
        QMutexLocker locker(&mutex);
        if (stopped) return;

        if (queue.size() >= maxSize) {
            queue.dequeue();  // 丢弃最旧的帧
        }
        queue.enqueue(frame.clone());
        notEmpty.wakeOne();//唤醒消费者
    }

    // 取出帧（消费者调用）
    bool pop(cv::Mat& frame, int timeoutMs = 100) {
        QMutexLocker locker(&mutex);
        while (queue.isEmpty() && !stopped) {
            if (!notEmpty.wait(&mutex, timeoutMs)) {
                if (stopped) return false;
            }
        }
        if (stopped && queue.isEmpty()) return false;
        frame = queue.dequeue().clone();
        return true;
    }

    // 停止队列
    void stop() {
        QMutexLocker locker(&mutex);
        stopped = true;
        notEmpty.wakeAll();//唤醒所有消费者，跳出循环
    }

    bool isStopped() const { return stopped; }

private:
    QQueue<cv::Mat> queue;
    QMutex mutex;
    QWaitCondition notEmpty;
    int maxSize;
    bool stopped;
};

#endif // FRAME_QUEUE_H
