#ifndef INFER_THREAD_H
#define INFER_THREAD_H

#include <QObject>
#include <QThread>
#include <QDebug>
#include <QImage>
#include <QElapsedTimer>
#include <opencv2/opencv.hpp>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <QTimer>
#include "file_utils.h"
#include "image_drawing.h"
#include "frame_queue.h"
#include "Mpp/mpprtspdecoder.h"
#include "yolov8_img/yolov8.h"

class infer_Thread : public QThread
{
    Q_OBJECT
public:
    explicit infer_Thread(FrameQueue* queue,QObject *parent = nullptr);
    ~infer_Thread();
    void run() override;
    void stop();
    int initInference();
    void releaseInference();

signals:
    void frameProcessed(QImage img,DetectionResults results);
    void move_send(int x);

private:
    FrameQueue* frameQueue;
    bool m_stop;
    bool inferenceInited;
    // RKNN 相关成员
    rknn_app_context_t rknn_app_ctx;
    // 计数器
    int cropCount;
    int weedCount;
    int targetCount;
    int rga_call_count;
    int target_x,target_y;
    int last_sent_x;
    int last_sent_y;
};

#endif // INFER_THREAD_H
