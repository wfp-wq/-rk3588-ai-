#ifndef WAIT_ANIMATION_H
#define WAIT_ANIMATION_H

#include<QPointer> //美化提示框需要
#include<QPropertyAnimation> //美化提示框需要
#include <QLabel>
#include <QTimer>
#include <QObject>

//Qt的工具类都需要继承QObject，因为qt的大部分工具类都继承自QObject
class Wait_Animation : public QObject
{
    Q_OBJECT
public:
    explicit Wait_Animation(QObject *parent = nullptr);

    // 显示浮动消息，需要传入父窗口指针以确定位置
    void showFloatingMessage(QWidget *parent, const QString& message, int timeout = 3000);

public:
    QPointer<QLabel> floatingMessageLabel; // 浮动消息标签
};

#endif
