#include "wait_animation.h"

Wait_Animation::Wait_Animation(QObject *parent) : QObject(parent)
{

}

void Wait_Animation::showFloatingMessage(QWidget *parent,const QString& message, int timeout)
{
    //如果存在上一次的提示信息，销毁它
    if (floatingMessageLabel) {
        floatingMessageLabel->deleteLater(); //安全销毁
    }

    //创建新的提示信息标签
    floatingMessageLabel = new QLabel(parent);
    floatingMessageLabel->setStyleSheet("background-color: rgba(0, 0, 0, 150); color: white; padding: 10px; border-radius: 5px;");
    floatingMessageLabel->setAlignment(Qt::AlignCenter);
    floatingMessageLabel->setFixedSize(400, 60); //设置固定大小

    //设置提示信息内容
    floatingMessageLabel->setText(message);

    //计算提示框的位置（居中显示）
    int x = (parent->width() - floatingMessageLabel->width()) / 2;
    int y = parent->height() - 500; // 距离底部 500 像素
    floatingMessageLabel->move(x, y);

    //显示提示框
    floatingMessageLabel->show();

    //使用 QTimer 设置定时器，在指定时间后销毁提示框
    QTimer::singleShot(timeout, this, [this]() {
        if (floatingMessageLabel) {
            //淡出动画
            QPropertyAnimation *animation = new QPropertyAnimation(floatingMessageLabel, "windowOpacity");
            animation->setDuration(1000); //动画持续时间
            animation->setStartValue(1.0); //初始透明度
            animation->setEndValue(0.0); //最终透明度
            animation->start(QAbstractAnimation::DeleteWhenStopped);
            //动画结束后销毁提示框
            connect(animation, &QPropertyAnimation::finished, floatingMessageLabel, &QLabel::deleteLater);
        }
    });
}
